import React from "react";
import { Flame, Monitor, RefreshCw, Trophy } from "lucide-react";

export function Hierarchy() {
  const teams = [
    { rank: 1, tag: "LOUD", name: "LOUD ESPORTS", flag: "🇧🇷", kills: 42, alive: 4 },
    { rank: 2, tag: "EVOS", name: "EVOS PHOENIX", flag: "🇹🇭", kills: 38, alive: 4 },
    { rank: 3, tag: "FLUX", name: "FLUXO", flag: "🇧🇷", kills: 31, alive: 3 },
    { rank: 4, tag: "VPE", name: "VAMPIRE ESPORTS", flag: "🇹🇭", kills: 28, alive: 2 },
    { rank: 5, tag: "TSM", name: "TSM FTX", flag: "🇮🇳", kills: 24, alive: 0 },
    { rank: 6, tag: "RRQ", name: "RRQ KAZU", flag: "🇮🇩", kills: 21, alive: 0 },
    { rank: 7, tag: "MNG", name: "MINERS.GG", flag: "🇧🇷", kills: 18, alive: 1 },
    { rank: 8, tag: "VK", name: "VIVO KEYD", flag: "🇧🇷", kills: 15, alive: 0 },
  ];

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-amber-500/30 overflow-x-hidden">
      {/* Navigation */}
      <nav className="w-full flex items-center justify-between px-6 py-4 md:px-12 border-b border-white/5">
        <div className="flex items-center gap-2">
          <Flame className="w-6 h-6 text-amber-400" fill="currentColor" />
          <span className="text-xl font-bold tracking-tight">FIREZONE</span>
        </div>
        <div className="flex items-center gap-6">
          <a href="#" className="text-sm font-medium text-white/60 hover:text-white transition-colors">
            Overlay
          </a>
          <button className="px-5 py-2 text-sm font-semibold bg-amber-400 text-black rounded-sm hover:bg-amber-300 transition-colors">
            Sign In
          </button>
        </div>
      </nav>

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-6 md:px-12 pt-24 pb-32">
        {/* Tier 1: Dominant Headline */}
        <div className="text-center md:text-left mb-16">
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black uppercase tracking-tighter leading-[0.9] flex flex-col">
            <span className="text-amber-400">LIVE FREE FIRE</span>
            <span className="text-white">TOURNAMENT OVERLAY</span>
          </h1>
        </div>

        {/* Separation Line */}
        <hr className="border-t border-white/10 mb-12" />

        {/* Tier 2: CTAs */}
        <div className="flex flex-col sm:flex-row items-center gap-4 md:gap-6 mb-16 md:justify-start">
          <button className="w-full sm:w-auto px-8 py-4 bg-amber-400 text-black font-bold text-lg rounded-sm hover:bg-amber-300 transition-colors flex items-center justify-center gap-2">
            Open Overlay
            <Monitor className="w-5 h-5" />
          </button>
          <button className="w-full sm:w-auto px-8 py-4 bg-transparent border-2 border-amber-400/50 text-amber-400 font-bold text-lg rounded-sm hover:bg-amber-400/10 transition-colors">
            Manage Teams
          </button>
        </div>

        {/* Tier 3: Contextual Info */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-start opacity-70 hover:opacity-100 transition-opacity duration-500">
          <div className="md:col-span-5 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs font-semibold tracking-wider text-white/80 uppercase">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              Broadcast Ready
            </div>
            <p className="text-lg md:text-xl text-white/60 font-medium leading-relaxed max-w-lg">
              Broadcast-grade live leaderboard for Free Fire esports. Real-time eliminations, alive players, country flags. Drop it into OBS and it just works.
            </p>
          </div>
          
          <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-amber-400/80">
                <RefreshCw className="w-4 h-4" />
                <span className="text-sm font-bold uppercase tracking-wider">Real-time</span>
              </div>
              <p className="text-sm text-white/50 font-medium">Instant updates</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-amber-400/80">
                <Monitor className="w-4 h-4" />
                <span className="text-sm font-bold uppercase tracking-wider">OBS</span>
              </div>
              <p className="text-sm text-white/50 font-medium">Browser source</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-amber-400/80">
                <Trophy className="w-4 h-4" />
                <span className="text-sm font-bold uppercase tracking-wider">Auto Sort</span>
              </div>
              <p className="text-sm text-white/50 font-medium">By eliminations</p>
            </div>
          </div>
        </div>

        {/* Section Break */}
        <div className="mt-32 mb-16 text-center">
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-white/30">Live Preview</span>
        </div>

        {/* Proof: Leaderboard Preview */}
        <div className="max-w-4xl mx-auto border border-white/10 bg-[#0a0a0a] rounded-lg overflow-hidden shadow-2xl shadow-amber-900/10">
          <div className="bg-black border-b border-white/5 px-6 py-4 flex justify-between items-center">
            <h3 className="font-black text-xl italic tracking-widest text-amber-400">MATCH #4 STANDINGS</h3>
            <div className="flex items-center gap-4 text-xs font-bold text-white/50">
              <span>ALIVE: 14</span>
              <span>KILLS</span>
            </div>
          </div>
          
          <div className="p-2 flex flex-col gap-1">
            {teams.map((team, idx) => (
              <div 
                key={team.tag}
                className="flex items-center justify-between p-3 bg-gradient-to-r from-white/5 to-transparent hover:from-white/10 transition-colors rounded"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-8 text-center font-black text-xl ${idx === 0 ? 'text-amber-400' : 'text-white/40'}`}>
                    {team.rank}
                  </div>
                  <div className="w-8 text-2xl filter drop-shadow-md">
                    {team.flag}
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-black text-lg tracking-wider">{team.tag}</span>
                      {team.alive > 0 ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-green-500/20 text-green-400">
                          {team.alive} ALIVE
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-500/20 text-red-400">
                          ELIMINATED
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-white/40 font-medium">{team.name}</span>
                  </div>
                </div>
                
                <div className="font-black text-2xl w-12 text-center text-amber-400">
                  {team.kills}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
