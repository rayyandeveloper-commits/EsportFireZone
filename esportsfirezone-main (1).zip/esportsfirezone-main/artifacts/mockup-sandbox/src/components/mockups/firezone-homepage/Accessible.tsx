import React from "react";
import { Flame, Play, Settings, Trophy, Monitor, BarChart3, Users } from "lucide-react";

export function Accessible() {
  const leaderboardData = [
    { rank: 1, tag: "EVOS", name: "EVOS Phoenix", flag: "🇹🇭", kills: 42, alive: 4 },
    { rank: 2, tag: "LOUD", name: "LOUD", flag: "🇧🇷", kills: 38, alive: 3 },
    { rank: 3, tag: "VK", name: "Vasto Mundo", flag: "🇵🇹", kills: 31, alive: 4 },
    { rank: 4, tag: "FLUX", name: "Fluxo", flag: "🇧🇷", kills: 27, alive: 0 },
    { rank: 5, tag: "MIG", name: "Magic Squad", flag: "🇧🇷", kills: 24, alive: 2 },
    { rank: 6, tag: "NGX", name: "Nigma Galaxy", flag: "🇦🇪", kills: 19, alive: 0 },
    { rank: 7, tag: "INF", name: "Infinity", flag: "🇨🇴", kills: 15, alive: 1 },
    { rank: 8, tag: "TSM", name: "TSM FTX", flag: "🇮🇳", kills: 12, alive: 0 },
  ];

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-amber-400 selection:text-black">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-6 max-w-7xl mx-auto border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="bg-amber-400 p-2 rounded-lg">
            <Flame className="w-6 h-6 text-black" strokeWidth={2.5} />
          </div>
          <span className="text-2xl font-bold tracking-widest text-white">FIREZONE</span>
        </div>
        <div className="flex items-center gap-8 text-lg font-medium">
          <a href="#" className="text-white hover:text-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-2 focus:ring-offset-black transition-colors rounded-sm">
            Overlay
          </a>
          <button className="bg-amber-400 text-black px-6 py-3 rounded-lg hover:bg-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-4 focus:ring-offset-black transition-all font-bold">
            Sign In
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 pt-24 pb-32 grid lg:grid-cols-2 gap-20 items-center">
        {/* Left Column: Copy & CTAs */}
        <div className="space-y-12">
          {/* Badge */}
          <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full border-2 border-amber-400/30 bg-amber-400/10">
            <span className="w-3 h-3 rounded-full bg-amber-400 animate-pulse" aria-hidden="true"></span>
            <span className="text-amber-400 font-bold tracking-widest uppercase text-sm">Broadcast Ready</span>
          </div>

          {/* Headlines */}
          <div className="space-y-4">
            <h1 className="text-amber-400 text-6xl md:text-7xl font-black uppercase leading-tight tracking-tight">
              Live Free Fire
              <br />
              <span className="text-white">Tournament Overlay</span>
            </h1>
          </div>

          {/* Subcopy */}
          <p className="text-gray-200 text-xl leading-relaxed max-w-xl font-medium">
            Broadcast-grade live leaderboard for Free Fire esports. Real-time eliminations, alive players, country flags. Drop it into OBS and it just works.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center gap-6">
            <button className="flex items-center gap-3 bg-amber-400 text-black px-8 py-4 rounded-xl hover:bg-amber-300 focus:outline-none focus:ring-4 focus:ring-amber-400 focus:ring-offset-4 focus:ring-offset-black transition-all font-bold text-lg">
              <Play className="w-6 h-6" aria-hidden="true" fill="currentColor" />
              Open Overlay
            </button>
            <button className="flex items-center gap-3 bg-transparent text-amber-400 px-8 py-4 rounded-xl border-2 border-amber-400 hover:bg-amber-400/10 focus:outline-none focus:ring-4 focus:ring-amber-400 focus:ring-offset-4 focus:ring-offset-black transition-all font-bold text-lg">
              <Settings className="w-6 h-6" aria-hidden="true" />
              Manage Teams
            </button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-10 border-t border-gray-800">
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-amber-400">
                <Trophy className="w-6 h-6" />
                <span className="font-bold text-lg text-white">Real-time</span>
              </div>
              <p className="text-gray-300 font-medium text-base leading-relaxed">Instant updates across all views.</p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-amber-400">
                <Monitor className="w-6 h-6" />
                <span className="font-bold text-lg text-white">OBS / Browser</span>
              </div>
              <p className="text-gray-300 font-medium text-base leading-relaxed">Simple browser source integration.</p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-amber-400">
                <BarChart3 className="w-6 h-6" />
                <span className="font-bold text-lg text-white">Auto Sort</span>
              </div>
              <p className="text-gray-300 font-medium text-base leading-relaxed">Ranked by points & eliminations.</p>
            </div>
          </div>
        </div>

        {/* Right Column: Leaderboard Preview */}
        <div className="relative p-1 bg-gradient-to-br from-gray-800 to-black rounded-3xl shadow-[0_0_50px_-12px_rgba(251,191,36,0.15)]">
          <div className="bg-[#0a0a0a] rounded-[22px] overflow-hidden border border-gray-800">
            {/* Header */}
            <div className="bg-gray-900 px-8 py-5 border-b border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-3 text-white font-bold text-xl tracking-wide uppercase">
                <Users className="text-amber-400 w-6 h-6" />
                Match Results
              </div>
              <div className="text-amber-400 font-bold bg-amber-400/10 px-4 py-2 rounded-lg text-sm tracking-wider uppercase border border-amber-400/20">
                Live
              </div>
            </div>

            {/* List */}
            <div className="p-4 space-y-3">
              {leaderboardData.map((team, index) => (
                <div 
                  key={team.name}
                  className={`flex items-center justify-between p-5 rounded-xl border ${index === 0 ? 'bg-amber-400/10 border-amber-400/50' : 'bg-gray-900 border-gray-800 hover:border-gray-700 hover:bg-gray-800/80'} transition-colors`}
                >
                  <div className="flex items-center gap-6">
                    <div className={`text-2xl font-black w-8 text-center ${index === 0 ? 'text-amber-400' : 'text-gray-300'}`}>
                      {team.rank}
                    </div>
                    <div className="text-3xl" aria-hidden="true">{team.flag}</div>
                    <div>
                      <div className="text-white font-bold text-xl leading-tight">{team.name}</div>
                      <div className="text-gray-300 font-bold uppercase tracking-wider text-sm mt-1">{team.tag}</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-8">
                    <div className="text-right">
                      <div className={`text-2xl font-black ${index === 0 ? 'text-amber-400' : 'text-white'} leading-none`}>
                        {team.kills}
                      </div>
                      <div className="text-gray-300 font-bold text-xs uppercase tracking-wider mt-2">Kills</div>
                    </div>
                    <div className="w-16 text-center">
                      <div className={`text-2xl font-black ${team.alive > 0 ? 'text-green-400' : 'text-red-400'} leading-none`}>
                        {team.alive}
                      </div>
                      <div className="text-gray-300 font-bold text-xs uppercase tracking-wider mt-2">Alive</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
