import React, { useState } from 'react';

export function Affordance() {
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);

  const leaderboardData = [
    { rank: 1, tag: 'LOUD', name: 'LOUD ESPORTS', flag: '🇧🇷', kills: 42, alive: 4 },
    { rank: 2, tag: 'EVOS', name: 'EVOS PHOENIX', flag: '🇹🇭', kills: 38, alive: 3 },
    { rank: 3, tag: 'FL', name: 'FLUXO', flag: '🇧🇷', kills: 31, alive: 4 },
    { rank: 4, tag: 'MQS', name: 'MAGIC SQUAD', flag: '🇧🇷', kills: 27, alive: 0 },
    { rank: 5, tag: 'BTR', name: 'BIGETRON DELTA', flag: '🇮🇩', kills: 24, alive: 2 },
    { rank: 6, tag: 'RRQ', name: 'RRQ KAZU', flag: '🇮🇩', kills: 21, alive: 0 },
    { rank: 7, tag: 'VAG', name: 'VAGABOND', flag: '🇪🇺', kills: 18, alive: 1 },
    { rank: 8, tag: 'CG', name: 'CGGG', flag: '🇹🇭', kills: 15, alive: 0 },
  ];

  return (
    <div className="min-h-screen bg-black text-white font-sans overflow-x-hidden selection:bg-amber-500/30">
      {/* Navigation */}
      <nav className="w-full flex items-center justify-between px-6 py-4 border-b border-white/10 relative z-10 bg-black/50 backdrop-blur-md">
        <div className="flex items-center gap-2 cursor-pointer group">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="w-8 h-8 text-amber-400 group-hover:text-amber-300 transition-colors duration-300"
          >
            <path
              fillRule="evenodd"
              d="M12.963 2.286a.75.75 0 00-1.071-.136 9.742 9.742 0 00-3.539 6.177A7.547 7.547 0 016.648 6.61a.75.75 0 00-1.152-.082A9 9 0 1015.68 4.534a7.46 7.46 0 01-2.717-2.248z"
              clipRule="evenodd"
            />
          </svg>
          <span className="font-black text-xl tracking-wider text-white">FIREZONE</span>
        </div>
        <div className="flex items-center gap-6">
          <button className="text-gray-300 hover:text-white font-medium text-sm transition-colors uppercase tracking-widest">
            Overlay
          </button>
          <button
            className="px-6 py-2 rounded-full border border-amber-400/50 text-amber-400 font-bold hover:bg-amber-400 hover:text-black transition-all duration-300 uppercase tracking-widest text-sm shadow-[0_0_15px_rgba(251,191,36,0.15)] hover:shadow-[0_0_20px_rgba(251,191,36,0.4)]"
            onMouseEnter={() => setHoveredButton('signin')}
            onMouseLeave={() => setHoveredButton(null)}
            style={{
              transform: hoveredButton === 'signin' ? 'scale(1.05)' : 'scale(1)',
            }}
          >
            Sign In
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 pt-20 pb-24 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Left Column - Copy & Actions */}
        <div className="flex flex-col items-start gap-8">
          <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm shadow-xl">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
            <span className="text-xs font-bold tracking-widest text-gray-300 uppercase">
              Broadcast Ready
            </span>
          </div>

          <h1 className="text-6xl md:text-7xl font-black leading-tight uppercase tracking-tight">
            <span className="text-amber-400 drop-shadow-[0_0_30px_rgba(251,191,36,0.3)] block">
              Live Free Fire
            </span>
            <span className="text-white block mt-2">Tournament Overlay</span>
          </h1>

          <p className="text-xl text-gray-400 font-medium leading-relaxed max-w-xl">
            Broadcast-grade live leaderboard for Free Fire esports. Real-time eliminations, alive
            players, country flags. Drop it into OBS and it just works.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-6 w-full sm:w-auto mt-4">
            <button
              className="w-full sm:w-auto flex items-center justify-center gap-3 px-10 py-5 bg-amber-400 text-black rounded-lg font-black text-lg uppercase tracking-wider transition-all duration-300 relative overflow-hidden shadow-[0_0_40px_rgba(251,191,36,0.3)]"
              onMouseEnter={() => setHoveredButton('primary')}
              onMouseLeave={() => setHoveredButton(null)}
              style={{
                transform: hoveredButton === 'primary' ? 'scale(1.05)' : 'scale(1)',
                boxShadow:
                  hoveredButton === 'primary'
                    ? '0 0 60px rgba(251,191,36,0.6)'
                    : '0 0 40px rgba(251,191,36,0.3)',
              }}
            >
              <span>Open Overlay</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={3}
                stroke="currentColor"
                className={`w-6 h-6 transition-transform duration-300 ${
                  hoveredButton === 'primary' ? 'translate-x-2' : ''
                }`}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
              </svg>
            </button>

            <button
              className="w-full sm:w-auto flex items-center justify-center gap-3 px-8 py-5 bg-transparent border-2 border-amber-400/30 text-amber-400 rounded-lg font-bold text-lg uppercase tracking-wider transition-all duration-300 hover:border-amber-400 hover:bg-amber-400/10"
              onMouseEnter={() => setHoveredButton('secondary')}
              onMouseLeave={() => setHoveredButton(null)}
              style={{
                transform: hoveredButton === 'secondary' ? 'scale(1.02)' : 'scale(1)',
              }}
            >
              <span>Manage Teams</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
                className="w-5 h-5"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75"
                />
              </svg>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mt-10 pt-10 border-t border-white/10 w-full">
            <div>
              <div className="text-amber-400 font-black text-xl mb-1">Real-time</div>
              <div className="text-gray-400 font-medium text-sm">Instant updates</div>
            </div>
            <div>
              <div className="text-amber-400 font-black text-xl mb-1">OBS</div>
              <div className="text-gray-400 font-medium text-sm">Browser source</div>
            </div>
            <div>
              <div className="text-amber-400 font-black text-xl mb-1">Auto Sort</div>
              <div className="text-gray-400 font-medium text-sm">By eliminations</div>
            </div>
          </div>
        </div>

        {/* Right Column - Preview Card */}
        <div className="relative">
          {/* Background Glows */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-amber-500/20 blur-[120px] rounded-full pointer-events-none"></div>

          {/* Leaderboard Card Container */}
          <div className="relative border border-white/10 rounded-2xl bg-[#0a0a0a]/90 backdrop-blur-xl shadow-2xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            {/* Header */}
            <div className="bg-gradient-to-r from-amber-500/20 to-transparent border-b border-amber-500/30 p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2 h-8 bg-amber-400 rounded-full"></div>
                <div>
                  <h3 className="font-black text-xl uppercase tracking-wider text-white">Match 1</h3>
                  <div className="text-amber-400 text-xs font-bold uppercase tracking-widest">
                    Live Leaderboard
                  </div>
                </div>
              </div>
              <div className="bg-black/50 px-3 py-1.5 rounded text-xs font-bold text-gray-300 border border-white/10">
                ALIVE: 14
              </div>
            </div>

            {/* Column Headers */}
            <div className="grid grid-cols-[40px_1fr_60px_60px] gap-4 px-6 py-3 bg-black/60 text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-white/5">
              <div className="text-center">#</div>
              <div>Team</div>
              <div className="text-center">Alive</div>
              <div className="text-center">Kills</div>
            </div>

            {/* Rows */}
            <div className="p-2 flex flex-col gap-1">
              {leaderboardData.map((team, idx) => (
                <div
                  key={team.tag}
                  className={`grid grid-cols-[40px_1fr_60px_60px] gap-4 items-center px-4 py-3 rounded-lg transition-colors ${
                    idx === 0
                      ? 'bg-amber-400/10 border border-amber-400/30'
                      : 'bg-white/5 border border-transparent hover:bg-white/10 hover:border-white/10'
                  }`}
                >
                  <div
                    className={`text-center font-black text-lg ${
                      idx === 0 ? 'text-amber-400' : 'text-gray-400'
                    }`}
                  >
                    {team.rank}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xl" role="img" aria-label={`Flag of ${team.name}`}>
                      {team.flag}
                    </span>
                    <div className="flex flex-col">
                      <span
                        className={`font-black uppercase tracking-wide leading-none ${
                          idx === 0 ? 'text-white drop-shadow-md' : 'text-gray-200'
                        }`}
                      >
                        {team.tag}
                      </span>
                      <span className="text-xs font-medium text-gray-500 uppercase truncate max-w-[120px]">
                        {team.name}
                      </span>
                    </div>
                  </div>
                  <div className="text-center">
                    <div
                      className={`inline-flex items-center justify-center w-6 h-6 rounded bg-black/50 font-bold text-sm ${
                        team.alive === 0 ? 'text-red-500' : 'text-white'
                      }`}
                    >
                      {team.alive}
                    </div>
                  </div>
                  <div className="text-center font-black text-xl text-white">{team.kills}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Copy URL micro-action */}
          <div className="absolute -bottom-6 right-6 z-20">
            <button
              className="flex items-center gap-2 bg-zinc-900 border border-zinc-700 hover:border-amber-400/50 hover:bg-zinc-800 text-gray-300 hover:text-amber-400 px-4 py-2 rounded-lg text-sm font-bold uppercase tracking-wider transition-all duration-300 shadow-lg group cursor-pointer"
              onMouseEnter={() => setHoveredButton('copy')}
              onMouseLeave={() => setHoveredButton(null)}
              style={{
                transform: hoveredButton === 'copy' ? 'translateY(-2px)' : 'translateY(0)',
              }}
            >
              <span>Copy OBS URL</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
                className="w-4 h-4 group-hover:scale-110 transition-transform"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.098 1.236.321 1.77.633M15.666 3.888c.142.348.23.73.23 1.112v12c0 1.657-1.343 3-3 3h-6c-1.657 0-3-1.343-3-3V10.5c0-1.657 1.343-3 3-3h.5m8.5 0A2.25 2.25 0 0119.5 10.5v12a2.25 2.25 0 01-2.25 2.25h-6A2.25 2.25 0 019 22.5V10.5"
                />
              </svg>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
