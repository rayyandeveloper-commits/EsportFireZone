
-- 1. Tournaments table
CREATE TABLE public.tournaments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.tournaments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tournaments are publicly viewable"
  ON public.tournaments FOR SELECT USING (true);

CREATE POLICY "Owners can insert tournaments"
  ON public.tournaments FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owners can update tournaments"
  ON public.tournaments FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Owners can delete tournaments"
  ON public.tournaments FOR DELETE USING (auth.uid() = user_id);

CREATE TRIGGER tournaments_set_updated_at
  BEFORE UPDATE ON public.tournaments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.tournaments;
ALTER TABLE public.tournaments REPLICA IDENTITY FULL;

-- 2. Add tournament_id to teams
ALTER TABLE public.teams
  ADD COLUMN IF NOT EXISTS tournament_id UUID REFERENCES public.tournaments(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS teams_tournament_id_idx ON public.teams(tournament_id);
