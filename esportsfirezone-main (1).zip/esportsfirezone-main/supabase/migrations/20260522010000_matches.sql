-- matches table: unlimited matches per tournament
CREATE TABLE IF NOT EXISTS public.matches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  match_number INT NOT NULL,
  name TEXT NOT NULL,
  is_live BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(tournament_id, match_number)
);

ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "matches_public_read" ON public.matches
  FOR SELECT USING (true);

CREATE POLICY "matches_owner_write" ON public.matches
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tournaments WHERE id = tournament_id AND user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.tournaments WHERE id = tournament_id AND user_id = auth.uid())
  );

-- Enforce one live match per tournament at a time
CREATE OR REPLACE FUNCTION enforce_single_live_match()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_live = TRUE THEN
    UPDATE public.matches
      SET is_live = FALSE
      WHERE tournament_id = NEW.tournament_id AND id != NEW.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER single_live_match_trigger
  AFTER INSERT OR UPDATE OF is_live ON public.matches
  FOR EACH ROW
  WHEN (NEW.is_live = TRUE)
  EXECUTE FUNCTION enforce_single_live_match();

-- team_match_scores: per-team, per-match scores (FFWS)
CREATE TABLE IF NOT EXISTS public.team_match_scores (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  match_id UUID NOT NULL REFERENCES public.matches(id) ON DELETE CASCADE,
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  placement INT NOT NULL DEFAULT 0,        -- 0 = not set, 1-12 = position
  kills INT NOT NULL DEFAULT 0,
  alive_players INT NOT NULL DEFAULT 0,
  placement_points INT NOT NULL DEFAULT 0, -- auto-computed by trigger
  kill_points INT NOT NULL DEFAULT 0,      -- = kills
  total_points INT NOT NULL DEFAULT 0,     -- placement_points + kill_points
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(team_id, match_id)
);

ALTER TABLE public.team_match_scores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "scores_public_read" ON public.team_match_scores
  FOR SELECT USING (true);

CREATE POLICY "scores_owner_write" ON public.team_match_scores
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tournaments WHERE id = tournament_id AND user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.tournaments WHERE id = tournament_id AND user_id = auth.uid())
  );

-- FFWS placement → points lookup
CREATE OR REPLACE FUNCTION ffws_placement_points(p INT) RETURNS INT AS $$
BEGIN
  RETURN CASE p
    WHEN 1  THEN 12
    WHEN 2  THEN 9
    WHEN 3  THEN 8
    WHEN 4  THEN 7
    WHEN 5  THEN 6
    WHEN 6  THEN 5
    WHEN 7  THEN 4
    WHEN 8  THEN 3
    WHEN 9  THEN 2
    WHEN 10 THEN 1
    ELSE 0
  END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Auto-compute points on upsert
CREATE OR REPLACE FUNCTION compute_match_points()
RETURNS TRIGGER AS $$
BEGIN
  NEW.placement_points := ffws_placement_points(NEW.placement);
  NEW.kill_points      := GREATEST(0, NEW.kills);
  NEW.total_points     := NEW.placement_points + NEW.kill_points;
  NEW.updated_at       := NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER auto_compute_points
  BEFORE INSERT OR UPDATE ON public.team_match_scores
  FOR EACH ROW EXECUTE FUNCTION compute_match_points();

-- Enable realtime for both tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.matches;
ALTER PUBLICATION supabase_realtime ADD TABLE public.team_match_scores;
