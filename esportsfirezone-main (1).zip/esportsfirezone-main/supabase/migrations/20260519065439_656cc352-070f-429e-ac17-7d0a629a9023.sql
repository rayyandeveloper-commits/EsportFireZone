insert into storage.buckets (id, name, public) values ('team-logos', 'team-logos', true) on conflict (id) do nothing;

create policy "Public read team logos" on storage.objects for select using (bucket_id = 'team-logos');
create policy "Public upload team logos" on storage.objects for insert with check (bucket_id = 'team-logos');
create policy "Public update team logos" on storage.objects for update using (bucket_id = 'team-logos');
create policy "Public delete team logos" on storage.objects for delete using (bucket_id = 'team-logos');