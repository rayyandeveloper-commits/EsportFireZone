
CREATE TABLE public.teams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  tag TEXT NOT NULL DEFAULT '',
  logo_url TEXT,
  country_code TEXT NOT NULL DEFAULT 'us',
  eliminations INT NOT NULL DEFAULT 0,
  alive_players INT NOT NULL DEFAULT 4,
  max_players INT NOT NULL DEFAULT 4,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read teams" ON public.teams FOR SELECT USING (true);
CREATE POLICY "Public insert teams" ON public.teams FOR INSERT WITH CHECK (true);
CREATE POLICY "Public update teams" ON public.teams FOR UPDATE USING (true);
CREATE POLICY "Public delete teams" ON public.teams FOR DELETE USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.teams;
ALTER TABLE public.teams REPLICA IDENTITY FULL;
