import { useTeams, type Team } from "@/lib/useTeams";
import { TeamRow } from "./TeamRow";
import { Flame } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  show: { opacity: 1, y: 0, scale: 1 },
};

export function Leaderboard({
  compact = false,
  teams: teamsProp,
  loading: loadingProp,
  flashId: flashIdProp,
}: {
  compact?: boolean;
  teams?: Team[];
  loading?: boolean;
  flashId?: string | null;
}) {
  const hook = useTeams(teamsProp ? null : undefined);
  const teams = teamsProp ?? hook.teams;
  const loading = loadingProp ?? hook.loading;
  const flashId = flashIdProp ?? hook.flashId;

  return (
    <div className={`flex w-full max-w-sm flex-col gap-2 ${compact ? "" : "p-4"}`}>
      {/* Header */}
      <div className="flex items-center justify-between rounded-md border border-gold/30 bg-gradient-to-r from-black/80 to-black/60 px-3 py-2 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Flame className="h-5 w-5 animate-pulse text-gold" strokeWidth={2.5} />
          <h2 className="font-display text-sm font-bold uppercase tracking-widest text-gold">
            Live Standings
          </h2>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive" />
          <span className="font-display text-[10px] font-bold uppercase tracking-wider text-foreground">
            LIVE
          </span>
        </div>
      </div>

      {/* List */}
      <motion.div
        className="flex flex-col gap-1.5"
        variants={containerVariants}
        initial="hidden"
        animate="show"
        key={teams.map((t) => t.id).join(",")} // re-trigger stagger on full reorder
      >
        {loading && (
          <div className="rounded-md bg-black/50 p-4 text-center text-xs text-muted-foreground">
            Connecting…
          </div>
        )}
        {!loading && teams.length === 0 && (
          <div className="rounded-md border border-white/5 bg-black/50 p-4 text-center text-xs text-muted-foreground">
            No teams yet. Add some in the admin panel.
          </div>
        )}
        <AnimatePresence mode="popLayout">
          {teams.map((team, i) => (
            <motion.div
              key={team.id}
              layout
              variants={itemVariants}
              initial="hidden"
              animate="show"
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
              transition={{
                layout: { type: "spring", stiffness: 350, damping: 30 },
              }}
            >
              <TeamRow
                team={team}
                rank={i + 1}
                flash={flashId === team.id}
              />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
