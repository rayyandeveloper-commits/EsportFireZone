import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Team } from "@/lib/useTeams";
import { COUNTRIES } from "@/lib/countries";
import { Upload, X, ImageIcon, Globe2, Check } from "lucide-react";
import { toast } from "sonner";

export function TeamMediaEditor({
  team,
  onUpdate,
}: {
  team: Team;
  onUpdate: (patch: Partial<Team>) => Promise<void>;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [search, setSearch] = useState("");

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image must be under 2 MB");
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop() ?? "png";
    const path = `${team.id}-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("team-logos")
      .upload(path, file, { upsert: true, contentType: file.type });
    if (upErr) {
      toast.error(upErr.message);
      setUploading(false);
      return;
    }
    const { data } = supabase.storage.from("team-logos").getPublicUrl(path);
    await onUpdate({ logo_url: data.publicUrl });
    toast.success("Logo updated");
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function clearLogo() {
    await onUpdate({ logo_url: null });
    toast.success("Logo removed");
  }

  const filtered = COUNTRIES.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.code.includes(search.toLowerCase()),
  );

  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* Logo preview + upload */}
      <div className="flex items-center gap-2 rounded-md border border-white/10 bg-secondary/40 p-1.5">
        <div className="flex h-9 w-9 items-center justify-center overflow-hidden rounded bg-black/40 ring-1 ring-white/10">
          {team.logo_url ? (
            <img src={team.logo_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <ImageIcon className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          onChange={handleFile}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="flex h-7 items-center gap-1 rounded bg-gold/15 px-2 font-display text-[10px] font-bold uppercase tracking-wider text-gold transition hover:bg-gold/25 disabled:opacity-50"
        >
          <Upload className="h-3 w-3" /> {uploading ? "…" : "Logo"}
        </button>
        {team.logo_url && (
          <button
            type="button"
            onClick={clearLogo}
            className="flex h-7 w-7 items-center justify-center rounded text-muted-foreground transition hover:bg-destructive/15 hover:text-destructive"
            title="Remove logo"
          >
            <X className="h-3 w-3" />
          </button>
        )}
      </div>

      {/* Country picker */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setPickerOpen((o) => !o)}
          className="flex h-[44px] items-center gap-2 rounded-md border border-white/10 bg-secondary/40 px-2 transition hover:bg-white/5"
        >
          <img
            src={`https://flagcdn.com/w40/${team.country_code}.png`}
            alt=""
            className="h-4 w-6 rounded-sm object-cover ring-1 ring-white/10"
          />
          <span className="font-display text-[10px] font-bold uppercase tracking-wider text-foreground">
            {team.country_code}
          </span>
          <Globe2 className="h-3 w-3 text-muted-foreground" />
        </button>

        {pickerOpen && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setPickerOpen(false)}
            />
            <div className="absolute right-0 top-full z-50 mt-1 w-64 overflow-hidden rounded-md border border-white/10 bg-card shadow-xl">
              <input
                autoFocus
                placeholder="Search country…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full border-b border-white/10 bg-transparent px-3 py-2 text-sm outline-none"
              />
              <div className="max-h-64 overflow-y-auto">
                {filtered.map((c) => {
                  const active = c.code === team.country_code;
                  return (
                    <button
                      key={c.code}
                      type="button"
                      onClick={async () => {
                        await onUpdate({ country_code: c.code });
                        setPickerOpen(false);
                        setSearch("");
                      }}
                      className={`flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm transition hover:bg-white/5 ${
                        active ? "bg-gold/10 text-gold" : ""
                      }`}
                    >
                      <img
                        src={`https://flagcdn.com/w40/${c.code}.png`}
                        alt=""
                        className="h-4 w-6 rounded-sm object-cover ring-1 ring-white/10"
                      />
                      <span className="flex-1 truncate">{c.name}</span>
                      <span className="font-mono text-[10px] uppercase text-muted-foreground">
                        {c.code}
                      </span>
                      {active && <Check className="h-3 w-3" />}
                    </button>
                  );
                })}
                {filtered.length === 0 && (
                  <div className="px-3 py-4 text-center text-xs text-muted-foreground">
                    No match
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
