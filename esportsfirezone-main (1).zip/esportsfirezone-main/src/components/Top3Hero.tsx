import { useRef } from "react";
import { motion, useMotionValue, useTransform, useSpring } from "framer-motion";
import { Crown, Skull } from "lucide-react";
import type { OverallStanding } from "@/lib/useOverallStandings";
import type { TeamMatchScore } from "@/lib/useMatchScores";

type CardData = {
  rank: number;
  team: { name: string; tag: string; logo_url: string | null; country_code: string };
  points: number;
  kills: number;
  label: string;
};

const MEDAL = {
  1: {
    border: "border-gold/60",
    glow: "shadow-[0_0_40px_-8px_oklch(0.82_0.17_85/0.7)]",
    bg: "bg-gradient-to-b from-gold/20 to-gold/5",
    text: "text-gold",
    badge: "bg-gold/25 text-gold ring-gold/40",
    crown: true,
  },
  2: {
    border: "border-silver/50",
    glow: "shadow-[0_0_30px_-8px_oklch(0.85_0.01_250/0.5)]",
    bg: "bg-gradient-to-b from-silver/15 to-silver/5",
    text: "text-silver",
    badge: "bg-silver/20 text-silver ring-silver/30",
    crown: false,
  },
  3: {
    border: "border-bronze/50",
    glow: "shadow-[0_0_30px_-8px_oklch(0.65_0.12_55/0.5)]",
    bg: "bg-gradient-to-b from-bronze/15 to-bronze/5",
    text: "text-bronze",
    badge: "bg-bronze/20 text-bronze ring-bronze/30",
    crown: false,
  },
} as const;

function HeroCard({ card, delay = 0 }: { card: CardData; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-60, 60], [12, -12]), { stiffness: 300, damping: 30 });
  const rotateY = useSpring(useTransform(x, [-60, 60], [-12, 12]), { stiffness: 300, damping: 30 });

  const medal = MEDAL[card.rank as 1 | 2 | 3];

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    x.set(e.clientX - rect.left - rect.width / 2);
    y.set(e.clientY - rect.top - rect.height / 2);
  }

  function handleMouseLeave() {
    x.set(0);
    y.set(0);
  }

  const isFirst = card.rank === 1;

  return (
    <motion.div
      ref={ref}
      style={{ rotateX, rotateY, transformPerspective: 800 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      initial={{ opacity: 0, y: 30, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay, duration: 0.5, type: "spring", stiffness: 200, damping: 22 }}
      className={`relative flex flex-col items-center gap-2 rounded-xl border p-4 backdrop-blur-md
        ${medal.border} ${medal.glow} ${medal.bg}
        ${isFirst ? "min-w-[110px]" : "min-w-[92px]"}
      `}
    >
      {/* Floating animation wrapper */}
      <motion.div
        className="flex w-full flex-col items-center gap-2"
        animate={{ y: [0, isFirst ? -6 : -4, 0] }}
        transition={{ repeat: Infinity, duration: isFirst ? 2.8 : 3.4, ease: "easeInOut", delay }}
      >
        {/* Rank badge */}
        {medal.crown ? (
          <Crown className="h-5 w-5 text-gold drop-shadow-[0_0_8px_oklch(0.82_0.17_85/0.9)]" strokeWidth={2} />
        ) : (
          <div
            className={`flex h-6 w-6 items-center justify-center rounded-full ring-1 font-display text-xs font-bold ${medal.badge}`}
          >
            {card.rank}
          </div>
        )}

        {/* Logo */}
        <div
          className={`flex items-center justify-center overflow-hidden rounded-lg bg-black/50 ring-2 ${medal.border}
            ${isFirst ? "h-16 w-16" : "h-12 w-12"}
          `}
        >
          {card.team.logo_url ? (
            <img src={card.team.logo_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className={`font-display font-black uppercase ${medal.text} ${isFirst ? "text-base" : "text-xs"}`}>
              {card.team.tag?.slice(0, 3)}
            </span>
          )}
        </div>

        {/* Flag + name */}
        <div className="flex flex-col items-center gap-0.5">
          <img
            src={`https://flagcdn.com/w40/${(card.team.country_code || "us").toLowerCase()}.png`}
            alt=""
            className="h-3 w-5 rounded-sm object-cover ring-1 ring-white/10"
          />
          <span className={`text-center font-display font-bold uppercase tracking-wide ${medal.text} ${isFirst ? "text-sm" : "text-[11px]"}`}>
            {card.team.name}
          </span>
        </div>

        {/* Points */}
        <div className={`flex flex-col items-center ${medal.text}`}>
          <span className={`font-display font-black tabular-nums leading-none ${isFirst ? "text-2xl" : "text-xl"}`}>
            {card.points}
          </span>
          <span className="font-display text-[9px] font-bold uppercase tracking-wider opacity-60">pts</span>
        </div>

        {/* Kills */}
        <div className="flex items-center gap-1 opacity-70">
          <Skull className={`h-3 w-3 ${medal.text}`} strokeWidth={2.5} />
          <span className={`font-display text-xs font-bold tabular-nums ${medal.text}`}>{card.kills}</span>
        </div>
      </motion.div>

      {/* Shimmer for 1st place */}
      {isFirst && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-xl" style={{ mixBlendMode: "overlay" }}>
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(105deg, transparent 35%, oklch(0.82 0.17 85 / 0.15) 42%, oklch(0.82 0.17 85 / 0.3) 50%, oklch(0.82 0.17 85 / 0.15) 58%, transparent 65%)",
              backgroundSize: "200% 100%",
              animation: "shimmer 3.5s linear infinite",
            }}
          />
        </div>
      )}
    </motion.div>
  );
}

function toCardFromScore(s: TeamMatchScore, rank: number): CardData {
  return {
    rank,
    team: s.team,
    points: s.total_points,
    kills: s.kills,
    label: `P${s.placement || "—"}`,
  };
}

function toCardFromStanding(s: OverallStanding, rank: number): CardData {
  return {
    rank,
    team: s.team,
    points: s.total_points,
    kills: s.total_kills,
    label: `${s.matches_played}M`,
  };
}

export function Top3Hero({
  scores,
  standings,
}: {
  scores?: TeamMatchScore[];
  standings?: OverallStanding[];
}) {
  let cards: CardData[] = [];

  if (scores && scores.length > 0) {
    cards = scores.slice(0, 3).map((s, i) => toCardFromScore(s, i + 1));
  } else if (standings && standings.length > 0) {
    cards = standings.slice(0, 3).map((s, i) => toCardFromStanding(s, i + 1));
  }

  if (cards.length < 2) return null;

  const first = cards[0];
  const second = cards[1];
  const third = cards[2] ?? null;

  return (
    <div className="flex items-end justify-center gap-2 px-2 pb-2">
      {/* 2nd place */}
      <div className="flex flex-col items-center gap-0">
        <HeroCard card={second} delay={0.1} />
        <div className="h-8 w-px bg-gradient-to-b from-silver/40 to-transparent" />
        <div className="h-2 w-20 rounded-t bg-silver/20 ring-1 ring-silver/20" />
      </div>

      {/* 1st place — raised */}
      <div className="flex flex-col items-center gap-0 -mt-6">
        <HeroCard card={first} delay={0} />
        <div className="h-14 w-px bg-gradient-to-b from-gold/40 to-transparent" />
        <div className="h-2 w-24 rounded-t bg-gold/20 ring-1 ring-gold/30" />
      </div>

      {/* 3rd place */}
      {third && (
        <div className="flex flex-col items-center gap-0">
          <HeroCard card={third} delay={0.2} />
          <div className="h-4 w-px bg-gradient-to-b from-bronze/40 to-transparent" />
          <div className="h-2 w-20 rounded-t bg-bronze/20 ring-1 ring-bronze/20" />
        </div>
      )}
    </div>
  );
}
