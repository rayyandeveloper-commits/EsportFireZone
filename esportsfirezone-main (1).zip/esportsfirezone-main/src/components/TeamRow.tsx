import { Skull, Crown } from "lucide-react";
import type { Team } from "@/lib/useTeams";

function CountryFlag({ code }: { code: string }) {
  const c = (code || "us").toLowerCase();
  return (
    <img
      src={`https://flagcdn.com/w40/${c}.png`}
      srcSet={`https://flagcdn.com/w80/${c}.png 2x`}
      alt={c}
      className="h-4 w-6 rounded-sm object-cover ring-1 ring-white/10"
      loading="lazy"
    />
  );
}

export function TeamRow({
  team,
  rank,
  flash,
}: {
  team: Team;
  rank: number;
  flash: boolean;
}) {
  const isTop = rank === 1;
  const isSecond = rank === 2;
  const isThird = rank === 3;

  const rankBorder = isTop
    ? "border-gold/50 shadow-[0_0_20px_-4px_oklch(0.82_0.17_85/0.5)]"
    : isSecond
      ? "border-silver/40 shadow-[0_0_16px_-4px_oklch(0.85_0.01_250/0.4)]"
      : isThird
        ? "border-bronze/40 shadow-[0_0_16px_-4px_oklch(0.65_0.12_55/0.4)]"
        : "border-white/5";

  const rankText = isTop
    ? "text-gold"
    : isSecond
      ? "text-silver"
      : isThird
        ? "text-bronze"
        : "text-muted-foreground";

  return (
    <div
      className={`group relative flex items-center gap-3 rounded-md border bg-black/55 px-3 py-2 backdrop-blur-md transition-all duration-500 ${rankBorder} ${
        flash ? "animate-flash" : ""
      }`}
    >
      {/* Rank 1 shimmer sweep */}
      {isTop && (
        <div
          className="pointer-events-none absolute inset-0 overflow-hidden rounded-md"
          style={{ mixBlendMode: "overlay" }}
        >
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(105deg, transparent 40%, oklch(0.82 0.17 85 / 0.15) 45%, oklch(0.82 0.17 85 / 0.25) 50%, oklch(0.82 0.17 85 / 0.15) 55%, transparent 60%)",
              backgroundSize: "200% 100%",
              animation: "shimmer 3s linear infinite",
            }}
          />
        </div>
      )}

      {/* Rank */}
      <div
        className={`flex h-8 w-7 shrink-0 items-center justify-center font-display text-lg font-bold ${rankText}`}
      >
        {isTop ? (
          <Crown className="h-5 w-5 text-gold" strokeWidth={2} />
        ) : (
          rank.toString().padStart(2, "0")
        )}
      </div>

      {/* Logo */}
      <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
        {team.logo_url ? (
          <img src={team.logo_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span className="font-display text-xs font-bold text-gold">
            {team.tag?.slice(0, 3).toUpperCase()}
          </span>
        )}
      </div>

      {/* Name + flag */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <CountryFlag code={team.country_code} />
          <span className="truncate font-display text-sm font-semibold uppercase tracking-wide text-foreground">
            {team.name}
          </span>
        </div>
        {/* Alive bars */}
        <div className="mt-1 flex gap-0.5">
          {Array.from({ length: team.max_players }).map((_, i) => {
            const alive = i < team.alive_players;
            return (
              <div
                key={i}
                className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                  alive
                    ? "bg-alive shadow-[0_0_6px_oklch(0.78_0.18_142/0.7)]"
                    : "bg-dead"
                }`}
              />
            );
          })}
        </div>
      </div>

      {/* Eliminations */}
      <div
        className={`flex shrink-0 items-center gap-1.5 rounded px-2 py-1 ring-1 ${
          isTop
            ? "bg-gold/15 ring-gold/40"
            : isSecond
              ? "bg-silver/10 ring-silver/30"
              : isThird
                ? "bg-bronze/10 ring-bronze/30"
                : "bg-gold/10 ring-gold/30"
        }`}
      >
        <Skull
          className={`h-3.5 w-3.5 ${
            isTop ? "text-gold" : isSecond ? "text-silver" : isThird ? "text-bronze" : "text-gold"
          }`}
          strokeWidth={2.5}
        />
        <span
          className={`font-display text-base font-bold tabular-nums ${
            isTop ? "text-gold" : isSecond ? "text-silver" : isThird ? "text-bronze" : "text-gold"
          }`}
        >
          {team.eliminations}
        </span>
      </div>
    </div>
  );
}
