import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type TeamMatchScore = {
  id: string;
  team_id: string;
  match_id: string;
  tournament_id: string;
  placement: number;
  kills: number;
  alive_players: number;
  placement_points: number;
  kill_points: number;
  total_points: number;
  updated_at: string;
  team: {
    id: string;
    name: string;
    tag: string;
    logo_url: string | null;
    country_code: string;
    max_players: number;
  };
};

export function useMatchScores(matchId: string | null | undefined) {
  const [scores, setScores] = useState<TeamMatchScore[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchScores = useCallback(async (mid: string) => {
    const { data } = await supabase
      .from("team_match_scores")
      .select("*, team:teams(id, name, tag, logo_url, country_code, max_players)")
      .eq("match_id", mid);
    if (data) setScores(data as TeamMatchScore[]);
  }, []);

  useEffect(() => {
    if (!matchId) {
      setScores([]);
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);

    supabase
      .from("team_match_scores")
      .select("*, team:teams(id, name, tag, logo_url, country_code, max_players)")
      .eq("match_id", matchId)
      .then(({ data }) => {
        if (active && data) setScores(data as TeamMatchScore[]);
        setLoading(false);
      });

    const channel = supabase
      .channel(`match-scores-${matchId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "team_match_scores", filter: `match_id=eq.${matchId}` },
        () => {
          if (active) fetchScores(matchId);
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [matchId, fetchScores]);

  const upsertScore = useCallback(
    async (score: {
      team_id: string;
      match_id: string;
      tournament_id: string;
      placement?: number;
      kills?: number;
      alive_players?: number;
    }) => {
      return supabase
        .from("team_match_scores")
        .upsert(score, { onConflict: "team_id,match_id" });
    },
    []
  );

  const sorted = [...scores].sort(
    (a, b) =>
      b.total_points - a.total_points ||
      b.kills - a.kills ||
      (a.placement > 0 ? a.placement : 99) - (b.placement > 0 ? b.placement : 99)
  );

  return { scores, sorted, loading, upsertScore };
}
