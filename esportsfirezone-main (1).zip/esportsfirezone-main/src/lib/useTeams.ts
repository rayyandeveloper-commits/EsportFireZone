import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Team = {
  id: string;
  name: string;
  tag: string;
  logo_url: string | null;
  country_code: string;
  eliminations: number;
  alive_players: number;
  max_players: number;
  position: number;
  user_id?: string | null;
  tournament_id?: string | null;
};

/**
 * @param tournamentId - undefined = all teams; null = no fetch (returns []); string = filter by tournament
 */
export function useTeams(tournamentId?: string | null) {
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [flashId, setFlashId] = useState<string | null>(null);

  useEffect(() => {
    if (tournamentId === null) {
      setTeams([]);
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    let q = supabase.from("teams").select("*");
    if (typeof tournamentId === "string") q = q.eq("tournament_id", tournamentId);
    q.then(({ data }) => {
      if (active && data) setTeams(data as Team[]);
      setLoading(false);
    });

    const channel = supabase
      .channel(`teams-live-${tournamentId ?? "all"}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "teams" },
        (payload) => {
          setTeams((prev) => {
            const matchesFilter = (row: Team) =>
              typeof tournamentId !== "string" || row.tournament_id === tournamentId;

            if (payload.eventType === "INSERT") {
              const row = payload.new as Team;
              return matchesFilter(row) ? [...prev, row] : prev;
            }
            if (payload.eventType === "DELETE") {
              return prev.filter((t) => t.id !== (payload.old as Team).id);
            }
            if (payload.eventType === "UPDATE") {
              const updated = payload.new as Team;
              if (!matchesFilter(updated)) return prev.filter((t) => t.id !== updated.id);
              setFlashId(updated.id);
              setTimeout(() => setFlashId(null), 700);
              return prev.some((t) => t.id === updated.id)
                ? prev.map((t) => (t.id === updated.id ? updated : t))
                : [...prev, updated];
            }
            return prev;
          });
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [tournamentId]);

  const sorted = [...teams].sort(
    (a, b) => b.eliminations - a.eliminations || b.alive_players - a.alive_players
  );

  return { teams: sorted, loading, flashId };
}
