import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { TeamMatchScore } from "./useMatchScores";

export type OverallStanding = {
  team_id: string;
  team: TeamMatchScore["team"];
  total_points: number;
  total_kills: number;
  matches_played: number;
  best_match_score: number;
  first_place_finishes: number;
};

export function useOverallStandings(tournamentId: string | null | undefined) {
  const [rawScores, setRawScores] = useState<TeamMatchScore[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!tournamentId) {
      setRawScores([]);
      setLoading(false);
      return;
    }

    let active = true;
    setLoading(true);

    const fetch = async () => {
      const { data } = await supabase
        .from("team_match_scores")
        .select("*, team:teams(id, name, tag, logo_url, country_code, max_players)")
        .eq("tournament_id", tournamentId);
      if (active && data) setRawScores(data as TeamMatchScore[]);
      if (active) setLoading(false);
    };

    fetch();

    const channel = supabase
      .channel(`overall-standings-${tournamentId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "team_match_scores",
          filter: `tournament_id=eq.${tournamentId}`,
        },
        () => {
          if (active) fetch();
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [tournamentId]);

  const standings = useMemo<OverallStanding[]>(() => {
    const map = new Map<string, OverallStanding>();

    for (const s of rawScores) {
      const existing = map.get(s.team_id);
      const participated = s.total_points > 0 || s.kills > 0 || s.placement > 0;

      if (!existing) {
        map.set(s.team_id, {
          team_id: s.team_id,
          team: s.team,
          total_points: s.total_points,
          total_kills: s.kills,
          matches_played: participated ? 1 : 0,
          best_match_score: s.total_points,
          first_place_finishes: s.placement === 1 ? 1 : 0,
        });
      } else {
        existing.total_points += s.total_points;
        existing.total_kills += s.kills;
        if (participated) existing.matches_played++;
        if (s.total_points > existing.best_match_score)
          existing.best_match_score = s.total_points;
        if (s.placement === 1) existing.first_place_finishes++;
      }
    }

    return [...map.values()].sort(
      (a, b) =>
        b.total_points - a.total_points ||
        b.total_kills - a.total_kills ||
        b.best_match_score - a.best_match_score ||
        b.first_place_finishes - a.first_place_finishes
    );
  }, [rawScores]);

  return { standings, loading };
}
