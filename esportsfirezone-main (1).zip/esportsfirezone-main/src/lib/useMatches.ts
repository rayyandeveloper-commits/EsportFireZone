import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Match = {
  id: string;
  tournament_id: string;
  match_number: number;
  name: string;
  is_live: boolean;
  created_at: string;
};

export function useMatches(tournamentId: string | null | undefined) {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!tournamentId) {
      setMatches([]);
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);

    supabase
      .from("matches")
      .select("*")
      .eq("tournament_id", tournamentId)
      .order("match_number", { ascending: true })
      .then(({ data }) => {
        if (active && data) setMatches(data as Match[]);
        setLoading(false);
      });

    const channel = supabase
      .channel(`matches-${tournamentId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "matches", filter: `tournament_id=eq.${tournamentId}` },
        (payload) => {
          setMatches((prev) => {
            const sorted = (arr: Match[]) =>
              [...arr].sort((a, b) => a.match_number - b.match_number);

            if (payload.eventType === "INSERT") {
              return sorted([...prev, payload.new as Match]);
            }
            if (payload.eventType === "DELETE") {
              return prev.filter((m) => m.id !== (payload.old as Match).id);
            }
            if (payload.eventType === "UPDATE") {
              return sorted(
                prev.map((m) => (m.id === (payload.new as Match).id ? (payload.new as Match) : m))
              );
            }
            return prev;
          });
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [tournamentId]);

  const createMatch = useCallback(
    async (tid: string) => {
      const nextNumber =
        matches.length > 0 ? Math.max(...matches.map((m) => m.match_number)) + 1 : 1;
      return supabase
        .from("matches")
        .insert({
          tournament_id: tid,
          match_number: nextNumber,
          name: `Match ${nextNumber}`,
          is_live: false,
        })
        .select()
        .single();
    },
    [matches]
  );

  const deleteMatch = useCallback(async (matchId: string) => {
    return supabase.from("matches").delete().eq("id", matchId);
  }, []);

  const setLive = useCallback(async (matchId: string, tid: string) => {
    await supabase.from("matches").update({ is_live: false }).eq("tournament_id", tid);
    return supabase.from("matches").update({ is_live: true }).eq("id", matchId);
  }, []);

  const unsetLive = useCallback(async (matchId: string) => {
    return supabase.from("matches").update({ is_live: false }).eq("id", matchId);
  }, []);

  const liveMatch = matches.find((m) => m.is_live) ?? null;

  return { matches, loading, createMatch, deleteMatch, setLive, unsetLive, liveMatch };
}
