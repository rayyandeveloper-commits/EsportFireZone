import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Tournament = {
  id: string;
  name: string;
  user_id: string;
  created_at: string;
  updated_at: string;
};

export function useTournaments(userId?: string | null) {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      setTournaments([]);
      setLoading(false);
      return;
    }

    let active = true;
    setLoading(true);

    supabase
      .from("tournaments")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        if (active && data) setTournaments(data as Tournament[]);
        setLoading(false);
      });

    const channel = supabase
      .channel(`tournaments-live-${userId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "tournaments", filter: `user_id=eq.${userId}` },
        (payload) => {
          setTournaments((prev) => {
            if (payload.eventType === "INSERT") {
              return [payload.new as Tournament, ...prev];
            }
            if (payload.eventType === "DELETE") {
              return prev.filter((t) => t.id !== (payload.old as Tournament).id);
            }
            if (payload.eventType === "UPDATE") {
              const updated = payload.new as Tournament;
              return prev.map((t) => (t.id === updated.id ? updated : t));
            }
            return prev;
          });
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [userId]);

  return { tournaments, loading };
}
