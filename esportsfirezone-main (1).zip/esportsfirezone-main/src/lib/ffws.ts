export const FFWS_PLACEMENT_POINTS: Record<number, number> = {
  1: 12, 2: 9, 3: 8, 4: 7, 5: 6,
  6: 5, 7: 4, 8: 3, 9: 2, 10: 1,
};

export function getPlacementPoints(placement: number): number {
  return FFWS_PLACEMENT_POINTS[placement] ?? 0;
}

export function getTotalPoints(placement: number, kills: number): number {
  return getPlacementPoints(placement) + Math.max(0, kills);
}

export const PLACEMENT_LABELS: Record<number, string> = {
  0: "—",
  1: "1st", 2: "2nd", 3: "3rd", 4: "4th",
  5: "5th", 6: "6th", 7: "7th", 8: "8th",
  9: "9th", 10: "10th", 11: "11th", 12: "12th",
};

export const RANK_COLORS = {
  1: { text: "text-gold", border: "border-gold/50", bg: "bg-gold/10", glow: "shadow-[0_0_20px_-4px_oklch(0.82_0.17_85/0.45)]" },
  2: { text: "text-silver", border: "border-silver/40", bg: "bg-silver/10", glow: "shadow-[0_0_16px_-4px_oklch(0.85_0.01_250/0.4)]" },
  3: { text: "text-bronze", border: "border-bronze/40", bg: "bg-bronze/10", glow: "shadow-[0_0_16px_-4px_oklch(0.65_0.12_55/0.4)]" },
} as const;
