import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, signOut } from "@/lib/useAuth";
import { useTeams, type Team } from "@/lib/useTeams";
import { useTournaments, type Tournament } from "@/lib/useTournaments";
import { useMatches, type Match } from "@/lib/useMatches";
import { useMatchScores } from "@/lib/useMatchScores";
import { useOverallStandings } from "@/lib/useOverallStandings";
import { getPlacementPoints, PLACEMENT_LABELS } from "@/lib/ffws";
import {
  Minus, Plus, Trash2, UserPlus, Flame, ExternalLink, Save,
  LogOut, Copy, Trophy, ChevronDown, ChevronRight, PlusCircle,
  Pencil, Check, X, Radio, BarChart3, Swords, RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { TeamMediaEditor } from "@/components/TeamMediaEditor";
import { COUNTRIES } from "@/lib/countries";
import { motion, AnimatePresence } from "framer-motion";

export const Route = createFileRoute("/admin")({
  component: Admin,
});

function Admin() {
  const navigate = useNavigate();
  const { user, userId, loading: authLoading } = useAuth();
  const { tournaments, loading: tLoading } = useTournaments(userId ?? null);
  const [activeTournamentId, setActiveTournamentId] = useState<string | null>(null);
  const [newTournamentName, setNewTournamentName] = useState("");
  const [creatingTournament, setCreatingTournament] = useState(false);
  const [editingTournamentId, setEditingTournamentId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/auth" });
  }, [authLoading, user, navigate]);

  useEffect(() => {
    if (!tLoading && tournaments.length > 0 && !activeTournamentId) {
      setActiveTournamentId(tournaments[0].id);
    }
  }, [tLoading, tournaments, activeTournamentId]);

  if (authLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
        Loading…
      </div>
    );
  }

  async function createTournament(e: React.FormEvent) {
    e.preventDefault();
    if (!newTournamentName.trim() || !userId) return;
    setCreatingTournament(true);
    const { data, error } = await supabase
      .from("tournaments")
      .insert({ name: newTournamentName.trim(), user_id: userId })
      .select()
      .single();
    setCreatingTournament(false);
    if (error) {
      toast.error(error.message);
    } else {
      toast.success(`Tournament "${newTournamentName.trim()}" created`);
      setNewTournamentName("");
      if (data) setActiveTournamentId(data.id);
    }
  }

  async function renameTournament(t: Tournament) {
    if (!editingName.trim()) return;
    const { error } = await supabase
      .from("tournaments")
      .update({ name: editingName.trim() })
      .eq("id", t.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Renamed");
      setEditingTournamentId(null);
    }
  }

  async function deleteTournament(t: Tournament) {
    if (!confirm(`Delete tournament "${t.name}"? All its teams and matches will be removed.`)) return;
    const { error } = await supabase.from("tournaments").delete().eq("id", t.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Tournament deleted");
      if (activeTournamentId === t.id) {
        const remaining = tournaments.filter((x) => x.id !== t.id);
        setActiveTournamentId(remaining[0]?.id ?? null);
      }
    }
  }

  async function handleSignOut() {
    await signOut();
    navigate({ to: "/" });
  }

  const activeTournament = tournaments.find((t) => t.id === activeTournamentId) ?? null;

  return (
    <div className="min-h-screen bg-background">
      <Toaster theme="dark" position="top-right" />

      <header className="border-b border-white/5 bg-card/50 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <Flame className="h-5 w-5 text-gold" strokeWidth={2.5} />
            <Link to="/" className="font-display text-lg font-bold uppercase tracking-widest">
              Fire<span className="text-gold">Zone</span>
            </Link>
            <span className="ml-2 rounded bg-gold/15 px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-wider text-gold">
              Admin
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden text-xs text-muted-foreground sm:inline">{user.email}</span>
            <button
              onClick={handleSignOut}
              className="flex h-9 w-9 items-center justify-center rounded-md border border-white/10 text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
              aria-label="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {/* Tournaments section */}
        <section className="mb-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-widest text-gold">
              <Trophy className="h-4 w-4" /> Tournaments
            </h2>
            <span className="text-xs text-muted-foreground">
              {tournaments.length} tournament{tournaments.length !== 1 ? "s" : ""}
            </span>
          </div>

          <form onSubmit={createTournament} className="mb-4 flex gap-2">
            <input
              required
              placeholder="New tournament name…"
              value={newTournamentName}
              onChange={(e) => setNewTournamentName(e.target.value)}
              className="flex-1 rounded-md border border-white/10 bg-input px-3 py-2 text-sm outline-none transition focus:border-gold"
            />
            <button
              type="submit"
              disabled={creatingTournament}
              className="flex items-center gap-1.5 rounded-md bg-gold px-4 py-2 font-display text-xs font-bold uppercase tracking-wider text-primary-foreground transition hover:bg-gold-glow disabled:opacity-50"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              {creatingTournament ? "Creating…" : "Create"}
            </button>
          </form>

          {tLoading && <div className="text-sm text-muted-foreground">Loading tournaments…</div>}
          {!tLoading && tournaments.length === 0 && (
            <div className="rounded-lg border border-dashed border-white/10 p-6 text-center text-sm text-muted-foreground">
              No tournaments yet. Create one above to get started.
            </div>
          )}

          <div className="space-y-2">
            <AnimatePresence initial={false}>
              {tournaments.map((t) => {
                const isActive = t.id === activeTournamentId;
                const overlayUrl = `${typeof window !== "undefined" ? window.location.origin : ""}/overlay/${t.id}`;
                const isEditing = editingTournamentId === t.id;

                return (
                  <motion.div
                    key={t.id}
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.97 }}
                    transition={{ duration: 0.2 }}
                    className={`rounded-xl border transition ${
                      isActive ? "border-gold/40 bg-gold/5" : "border-white/5 bg-card hover:border-white/10"
                    }`}
                  >
                    <div className="flex items-center gap-3 px-4 py-3">
                      <button
                        onClick={() => setActiveTournamentId(isActive ? null : t.id)}
                        className="flex flex-1 items-center gap-3 text-left"
                      >
                        <span className={`transition ${isActive ? "text-gold" : "text-muted-foreground"}`}>
                          {isActive ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </span>
                        {isEditing ? (
                          <input
                            autoFocus
                            value={editingName}
                            onChange={(e) => setEditingName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") renameTournament(t);
                              if (e.key === "Escape") setEditingTournamentId(null);
                            }}
                            onClick={(e) => e.stopPropagation()}
                            className="flex-1 rounded border border-gold/40 bg-black/30 px-2 py-1 text-sm outline-none focus:border-gold"
                          />
                        ) : (
                          <span className="flex-1 font-display text-sm font-semibold uppercase tracking-wide">
                            {t.name}
                          </span>
                        )}
                      </button>

                      <div className="flex items-center gap-1.5">
                        {isEditing ? (
                          <>
                            <button
                              onClick={() => renameTournament(t)}
                              className="flex h-7 w-7 items-center justify-center rounded text-alive transition hover:bg-alive/10"
                            >
                              <Check className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => setEditingTournamentId(null)}
                              className="flex h-7 w-7 items-center justify-center rounded text-muted-foreground transition hover:bg-white/5"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => { setEditingTournamentId(t.id); setEditingName(t.name); }}
                              className="flex h-7 w-7 items-center justify-center rounded text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
                              title="Rename"
                            >
                              <Pencil className="h-3 w-3" />
                            </button>
                            <button
                              onClick={() => { navigator.clipboard.writeText(overlayUrl); toast.success("Overlay URL copied"); }}
                              className="flex items-center gap-1.5 rounded border border-white/10 px-2.5 py-1 text-xs font-semibold text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
                            >
                              <Copy className="h-3 w-3" /> Copy URL
                            </button>
                            <a
                              href={overlayUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1 rounded border border-gold/30 px-2.5 py-1 font-display text-xs font-bold uppercase tracking-wider text-gold transition hover:bg-gold/10"
                            >
                              <ExternalLink className="h-3 w-3" /> Overlay
                            </a>
                            <button
                              onClick={() => deleteTournament(t)}
                              className="flex h-7 w-7 items-center justify-center rounded text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
                              title="Delete tournament"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    <AnimatePresence>
                      {isActive && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden border-t border-gold/20"
                        >
                          <div className="px-4 py-2">
                            <div className="mb-1 font-display text-[10px] uppercase tracking-wider text-gold/70">
                              OBS Browser Source URL · 420×900 · Transparent
                            </div>
                            <code className="block w-full truncate rounded bg-black/40 px-3 py-1.5 font-mono text-xs text-foreground">
                              {overlayUrl}
                            </code>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </section>

        {/* Tournament workspace */}
        <AnimatePresence mode="wait">
          {activeTournament ? (
            <motion.div
              key={activeTournament.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
            >
              <TournamentWorkspace tournament={activeTournament} userId={userId!} />
            </motion.div>
          ) : (
            <motion.div
              key="no-tournament"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="rounded-lg border border-dashed border-white/10 p-10 text-center text-sm text-muted-foreground"
            >
              Select or create a tournament above to manage it.
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

type WorkspaceTab = "teams" | string; // string = match id

function TournamentWorkspace({ tournament, userId }: { tournament: Tournament; userId: string }) {
  const { teams, loading: teamsLoading } = useTeams(tournament.id);
  const { matches, loading: matchesLoading, createMatch, deleteMatch, setLive, unsetLive, liveMatch } = useMatches(tournament.id);
  const { standings } = useOverallStandings(tournament.id);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>("teams");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (!matchesLoading && matches.length > 0 && activeTab === "teams") {
      // keep teams tab as default
    }
  }, [matchesLoading, matches, activeTab]);

  async function handleCreateMatch() {
    setCreating(true);
    const { data, error } = await createMatch(tournament.id);
    setCreating(false);
    if (error) toast.error(error.message);
    else if (data) {
      toast.success(`${data.name} created`);
      setActiveTab(data.id);
    }
  }

  async function handleDeleteMatch(m: Match) {
    if (!confirm(`Delete "${m.name}"? All its scores will be removed.`)) return;
    const { error } = await deleteMatch(m.id);
    if (error) toast.error(error.message);
    else {
      toast.success(`${m.name} deleted`);
      setActiveTab("teams");
    }
  }

  async function handleSetLive(m: Match) {
    if (m.is_live) {
      await unsetLive(m.id);
      toast.success(`${m.name} unset from live`);
    } else {
      await setLive(m.id, tournament.id);
      toast.success(`${m.name} is now LIVE`);
    }
  }

  const isOverall = activeTab === "overall";
  const activeMatch = matches.find((m) => m.id === activeTab) ?? null;

  return (
    <div>
      {/* Tab bar */}
      <div className="mb-6 flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setActiveTab("teams")}
          className={`flex shrink-0 items-center gap-1.5 rounded-md px-3 py-2 font-display text-xs font-bold uppercase tracking-wider transition
            ${activeTab === "teams" ? "bg-gold/15 text-gold ring-1 ring-gold/30" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`}
        >
          <UserPlus className="h-3.5 w-3.5" /> Teams
        </button>

        {matches.map((m) => (
          <button
            key={m.id}
            onClick={() => setActiveTab(m.id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-md px-3 py-2 font-display text-xs font-bold uppercase tracking-wider transition
              ${activeTab === m.id ? "bg-gold/15 text-gold ring-1 ring-gold/30" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`}
          >
            {m.is_live && (
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive" />
            )}
            <Swords className="h-3 w-3" />
            {m.name}
          </button>
        ))}

        <button
          onClick={handleCreateMatch}
          disabled={creating}
          className="flex shrink-0 items-center gap-1 rounded-md border border-dashed border-white/20 px-3 py-2 font-display text-xs font-bold uppercase tracking-wider text-muted-foreground transition hover:border-gold/40 hover:text-gold disabled:opacity-40"
        >
          <PlusCircle className="h-3.5 w-3.5" />
          {creating ? "…" : "New Match"}
        </button>

        {matches.length > 0 && (
          <button
            onClick={() => setActiveTab("overall")}
            className={`flex shrink-0 items-center gap-1.5 rounded-md px-3 py-2 font-display text-xs font-bold uppercase tracking-wider transition
              ${isOverall ? "bg-gold/15 text-gold ring-1 ring-gold/30" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`}
          >
            <BarChart3 className="h-3.5 w-3.5" /> Overall
          </button>
        )}
      </div>

      {/* Tab content */}
      <AnimatePresence mode="wait">
        {activeTab === "teams" && (
          <motion.div key="teams" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
            <TeamsSection tournament={tournament} userId={userId} teams={teams} loading={teamsLoading} />
          </motion.div>
        )}

        {activeMatch && (
          <motion.div key={activeMatch.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
            <MatchScorePanel
              match={activeMatch}
              tournament={tournament}
              teams={teams}
              onSetLive={() => handleSetLive(activeMatch)}
              onDelete={() => handleDeleteMatch(activeMatch)}
            />
          </motion.div>
        )}

        {isOverall && (
          <motion.div key="overall" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
            <OverallPanel standings={standings} matchCount={matches.length} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TeamsSection({
  tournament, userId, teams, loading,
}: {
  tournament: Tournament;
  userId: string;
  teams: Team[];
  loading: boolean;
}) {
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", tag: "", country_code: "us", logo_url: "", max_players: 4 });

  async function addTeam(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setAdding(true);
    const { error } = await supabase.from("teams").insert({
      name: form.name.trim(),
      tag: form.tag.trim() || form.name.slice(0, 3).toUpperCase(),
      country_code: form.country_code.toLowerCase() || "us",
      logo_url: form.logo_url.trim() || null,
      max_players: form.max_players,
      alive_players: form.max_players,
      eliminations: 0,
      user_id: userId,
      tournament_id: tournament.id,
    });
    setAdding(false);
    if (error) toast.error(error.message);
    else {
      toast.success(`${form.name} added`);
      setForm({ name: "", tag: "", country_code: "us", logo_url: "", max_players: 4 });
    }
  }

  async function remove(t: Team) {
    if (!confirm(`Delete ${t.name}?`)) return;
    await supabase.from("teams").delete().eq("id", t.id);
    toast.success("Team removed");
  }

  return (
    <div>
      <div className="mb-4">
        <h2 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-widest text-gold">
          <UserPlus className="h-4 w-4" /> Teams — {tournament.name}
        </h2>
      </div>

      <section className="mb-6 rounded-xl border border-white/5 bg-card p-5">
        <form onSubmit={addTeam} className="grid gap-3 md:grid-cols-6">
          <input
            required
            placeholder="Team name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="rounded-md border border-white/10 bg-input px-3 py-2 text-sm outline-none focus:border-gold md:col-span-2"
          />
          <input
            placeholder="TAG"
            maxLength={6}
            value={form.tag}
            onChange={(e) => setForm({ ...form, tag: e.target.value.toUpperCase() })}
            className="rounded-md border border-white/10 bg-input px-3 py-2 text-sm uppercase outline-none focus:border-gold"
          />
          <select
            value={form.country_code}
            onChange={(e) => setForm({ ...form, country_code: e.target.value })}
            className="rounded-md border border-white/10 bg-input px-3 py-2 text-sm outline-none focus:border-gold"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>{c.code.toUpperCase()} — {c.name}</option>
            ))}
          </select>
          <input
            placeholder="Logo URL (optional)"
            value={form.logo_url}
            onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
            className="rounded-md border border-white/10 bg-input px-3 py-2 text-sm outline-none focus:border-gold md:col-span-2"
          />
          <div className="flex items-center gap-2 md:col-span-6">
            <label className="text-xs text-muted-foreground">Max players</label>
            <input
              type="number" min={1} max={6}
              value={form.max_players}
              onChange={(e) => setForm({ ...form, max_players: Number(e.target.value) })}
              className="w-16 rounded-md border border-white/10 bg-input px-2 py-1 text-sm outline-none focus:border-gold"
            />
            <button
              type="submit"
              disabled={adding}
              className="ml-auto flex items-center gap-1.5 rounded-md bg-gold px-5 py-2 font-display text-xs font-bold uppercase tracking-wider text-primary-foreground transition hover:bg-gold-glow disabled:opacity-50"
            >
              <Save className="h-3.5 w-3.5" /> {adding ? "Adding…" : "Add Team"}
            </button>
          </div>
        </form>
      </section>

      <div className="mb-2 font-display text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Roster ({teams.length})
      </div>
      <div className="space-y-2">
        {loading && <div className="text-sm text-muted-foreground">Loading…</div>}
        {!loading && teams.length === 0 && (
          <div className="rounded-lg border border-dashed border-white/10 p-8 text-center text-sm text-muted-foreground">
            No teams yet. Add your first team above.
          </div>
        )}
        <AnimatePresence initial={false}>
          {teams.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.18 }}
              className="flex items-center gap-3 rounded-lg border border-white/5 bg-card p-3"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
                {t.logo_url ? (
                  <img src={t.logo_url} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="font-display text-[10px] font-bold text-gold">{t.tag?.slice(0, 3).toUpperCase()}</span>
                )}
              </div>
              <img src={`https://flagcdn.com/w40/${t.country_code}.png`} alt="" className="h-4 w-6 rounded-sm object-cover ring-1 ring-white/10" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-display text-sm font-semibold uppercase tracking-wide">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.tag} · {t.max_players}v{t.max_players}</div>
              </div>
              <TeamMediaEditor team={t} />
              <button
                onClick={() => remove(t)}
                className="flex h-8 w-8 items-center justify-center rounded text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

function MatchScorePanel({
  match, tournament, teams, onSetLive, onDelete,
}: {
  match: Match;
  tournament: Tournament;
  teams: Team[];
  onSetLive: () => void;
  onDelete: () => void;
}) {
  const { scores, upsertScore } = useMatchScores(match.id);

  const mergedRows = teams.map((team) => {
    const score = scores.find((s) => s.team_id === team.id);
    return { team, score };
  });

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <h2 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-widest text-gold">
          <Swords className="h-4 w-4" /> {match.name} — {tournament.name}
        </h2>
        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={onSetLive}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 font-display text-xs font-bold uppercase tracking-wider transition
              ${match.is_live
                ? "bg-destructive/20 text-destructive ring-1 ring-destructive/40 hover:bg-destructive/10"
                : "border border-white/10 text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
          >
            <Radio className="h-3.5 w-3.5" />
            {match.is_live ? "● Live (click to unset)" : "Set Live"}
          </button>
          <button
            onClick={onDelete}
            className="flex h-8 w-8 items-center justify-center rounded border border-white/10 text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
            title="Delete match"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {teams.length === 0 ? (
        <div className="rounded-lg border border-dashed border-white/10 p-10 text-center text-sm text-muted-foreground">
          Add teams in the Teams tab first, then come back here to score them.
        </div>
      ) : (
        <div className="rounded-xl border border-white/5 bg-card overflow-hidden">
          <div className="grid grid-cols-[1fr_auto_auto_auto_auto] gap-0 divide-y divide-white/5">
            <div className="col-span-5 grid grid-cols-[1fr_auto_auto_auto_auto] bg-white/5 px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
              <span>Team</span>
              <span className="w-28 text-center">Placement</span>
              <span className="w-24 text-center">Kills</span>
              <span className="w-20 text-center">Alive</span>
              <span className="w-16 text-center">Pts</span>
            </div>
            {mergedRows.map(({ team, score }) => (
              <TeamScoreRow
                key={team.id}
                team={team}
                score={score}
                matchId={match.id}
                tournamentId={tournament.id}
                onUpsert={upsertScore}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function TeamScoreRow({
  team, score, matchId, tournamentId, onUpsert,
}: {
  team: Team;
  score?: ReturnType<typeof useMatchScores>["scores"][number];
  matchId: string;
  tournamentId: string;
  onUpsert: ReturnType<typeof useMatchScores>["upsertScore"];
}) {
  const [placement, setPlacement] = useState(score?.placement ?? 0);
  const [kills, setKills] = useState(score?.kills ?? 0);
  const [alive, setAlive] = useState(score?.alive_players ?? 0);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setPlacement(score?.placement ?? 0);
    setKills(score?.kills ?? 0);
    setAlive(score?.alive_players ?? 0);
  }, [score?.placement, score?.kills, score?.alive_players]);

  const save = useCallback(
    async (p: number, k: number, a: number) => {
      setSaving(true);
      await onUpsert({ team_id: team.id, match_id: matchId, tournament_id: tournamentId, placement: p, kills: k, alive_players: a });
      setSaving(false);
    },
    [team.id, matchId, tournamentId, onUpsert]
  );

  const computedPts = getPlacementPoints(placement) + kills;

  function changePlacement(val: number) {
    setPlacement(val);
    save(val, kills, alive);
  }

  function changeKills(delta: number) {
    const next = Math.max(0, kills + delta);
    setKills(next);
    save(placement, next, alive);
  }

  function changeAlive(delta: number) {
    const next = Math.max(0, Math.min(team.max_players, alive + delta));
    setAlive(next);
    save(placement, kills, next);
  }

  return (
    <div className={`col-span-5 grid grid-cols-[1fr_auto_auto_auto_auto] items-center gap-0 px-4 py-3 transition ${saving ? "opacity-70" : ""}`}>
      {/* Team info */}
      <div className="flex items-center gap-2 min-w-0">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
          {team.logo_url ? (
            <img src={team.logo_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="font-display text-[9px] font-bold text-gold">{team.tag?.slice(0, 3)}</span>
          )}
        </div>
        <img src={`https://flagcdn.com/w40/${team.country_code}.png`} alt="" className="h-3.5 w-5 shrink-0 rounded-sm object-cover ring-1 ring-white/10" />
        <span className="truncate font-display text-xs font-semibold uppercase tracking-wide">{team.name}</span>
      </div>

      {/* Placement */}
      <div className="flex w-28 justify-center">
        <select
          value={placement}
          onChange={(e) => changePlacement(Number(e.target.value))}
          className="w-24 rounded-md border border-white/10 bg-input px-2 py-1 text-center text-xs outline-none focus:border-gold"
        >
          {Array.from({ length: 13 }, (_, i) => (
            <option key={i} value={i}>{PLACEMENT_LABELS[i]}</option>
          ))}
        </select>
      </div>

      {/* Kills */}
      <div className="flex w-24 items-center justify-center gap-1">
        <button onClick={() => changeKills(-1)} disabled={kills <= 0} className="flex h-6 w-6 items-center justify-center rounded bg-white/5 text-muted-foreground transition hover:bg-white/10 disabled:opacity-30">
          <Minus className="h-3 w-3" />
        </button>
        <span className="w-6 text-center font-display text-sm font-bold tabular-nums">{kills}</span>
        <button onClick={() => changeKills(1)} className="flex h-6 w-6 items-center justify-center rounded bg-white/5 text-muted-foreground transition hover:bg-white/10">
          <Plus className="h-3 w-3" />
        </button>
      </div>

      {/* Alive */}
      <div className="flex w-20 items-center justify-center gap-1">
        <button onClick={() => changeAlive(-1)} disabled={alive <= 0} className="flex h-6 w-6 items-center justify-center rounded bg-white/5 text-muted-foreground transition hover:bg-white/10 disabled:opacity-30">
          <Minus className="h-3 w-3" />
        </button>
        <span className="w-4 text-center font-display text-sm font-bold tabular-nums">{alive}</span>
        <button onClick={() => changeAlive(1)} disabled={alive >= team.max_players} className="flex h-6 w-6 items-center justify-center rounded bg-white/5 text-muted-foreground transition hover:bg-white/10 disabled:opacity-30">
          <Plus className="h-3 w-3" />
        </button>
      </div>

      {/* Points */}
      <div className="flex w-16 justify-center">
        <span className={`font-display text-base font-black tabular-nums ${computedPts > 0 ? "text-gold" : "text-muted-foreground"}`}>
          {computedPts}
        </span>
      </div>
    </div>
  );
}

function OverallPanel({ standings, matchCount }: { standings: ReturnType<typeof useOverallStandings>["standings"]; matchCount: number }) {
  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-widest text-gold">
          <BarChart3 className="h-4 w-4" /> Overall Standings
        </h2>
        <span className="text-xs text-muted-foreground">{matchCount} match{matchCount !== 1 ? "es" : ""} played</span>
      </div>

      {standings.length === 0 ? (
        <div className="rounded-lg border border-dashed border-white/10 p-10 text-center text-sm text-muted-foreground">
          No scores recorded yet. Go to a match tab and start entering results.
        </div>
      ) : (
        <div className="rounded-xl border border-white/5 bg-card overflow-hidden">
          <div className="divide-y divide-white/5">
            <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] bg-white/5 px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground gap-4">
              <span className="w-6 text-center">#</span>
              <span>Team</span>
              <span className="w-16 text-center">Pts</span>
              <span className="w-16 text-center">Kills</span>
              <span className="w-16 text-center">Matches</span>
              <span className="w-16 text-center">Best</span>
            </div>
            <AnimatePresence initial={false}>
              {standings.map((s, i) => (
                <motion.div
                  key={s.team_id}
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`grid grid-cols-[auto_1fr_auto_auto_auto_auto] items-center gap-4 px-4 py-3 ${
                    i === 0 ? "bg-gold/5" : i === 1 ? "bg-silver/5" : i === 2 ? "bg-bronze/5" : ""
                  }`}
                >
                  <span className={`w-6 text-center font-display text-sm font-bold ${i === 0 ? "text-gold" : i === 1 ? "text-silver" : i === 2 ? "text-bronze" : "text-muted-foreground"}`}>
                    {i + 1}
                  </span>
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
                      {s.team.logo_url ? (
                        <img src={s.team.logo_url} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <span className="font-display text-[9px] font-bold text-gold">{s.team.tag?.slice(0, 3)}</span>
                      )}
                    </div>
                    <img src={`https://flagcdn.com/w40/${s.team.country_code}.png`} alt="" className="h-3.5 w-5 shrink-0 rounded-sm object-cover ring-1 ring-white/10" />
                    <span className="truncate font-display text-xs font-semibold uppercase tracking-wide">{s.team.name}</span>
                  </div>
                  <span className={`w-16 text-center font-display text-base font-black tabular-nums ${i === 0 ? "text-gold" : i === 1 ? "text-silver" : i === 2 ? "text-bronze" : "text-foreground"}`}>
                    {s.total_points}
                  </span>
                  <span className="w-16 text-center font-display text-sm font-bold tabular-nums text-muted-foreground">{s.total_kills}</span>
                  <span className="w-16 text-center text-xs text-muted-foreground">{s.matches_played}</span>
                  <span className="w-16 text-center text-xs text-muted-foreground">{s.best_match_score}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}
    </div>
  );
}
