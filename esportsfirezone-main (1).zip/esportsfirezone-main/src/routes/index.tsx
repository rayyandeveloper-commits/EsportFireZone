import { createFileRoute, Link } from "@tanstack/react-router";
import { Leaderboard } from "@/components/Leaderboard";
import { Flame, Radio, Settings, Monitor, LogIn } from "lucide-react";
import { useAuth, signOut } from "@/lib/useAuth";
import { motion } from "framer-motion";

export const Route = createFileRoute("/")({
  component: Index,
});

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1], delay },
});

const fadeIn = (delay = 0) => ({
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  transition: { duration: 0.6, delay },
});

function Index() {
  const { user } = useAuth();

  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      {/* Background glow */}
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6, ease: "easeOut" }}
          className="absolute -left-40 top-0 h-[500px] w-[500px] rounded-full bg-gold/10 blur-[120px]"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6, ease: "easeOut", delay: 0.3 }}
          className="absolute -right-40 bottom-0 h-[500px] w-[500px] rounded-full bg-destructive/10 blur-[140px]"
        />
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage:
              "linear-gradient(oklch(0.82 0.17 85) 1px, transparent 1px), linear-gradient(90deg, oklch(0.82 0.17 85) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />
      </div>

      {/* Nav */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative z-10 flex items-center justify-between px-6 py-5 md:px-12"
      >
        <motion.div
          className="flex items-center gap-2"
          whileHover={{ scale: 1.04 }}
          transition={{ type: "spring", stiffness: 400, damping: 20 }}
        >
          <Flame className="h-6 w-6 text-gold" strokeWidth={2.5} />
          <span className="font-display text-lg font-bold uppercase tracking-widest">
            Fire<span className="text-gold">Zone</span>
          </span>
        </motion.div>
        <nav className="flex items-center gap-2">
          <motion.div {...fadeIn(0.1)}>
            <Link
              to="/overlay"
              className="rounded-md px-3 py-2 font-display text-xs font-semibold uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
            >
              <span className="hidden sm:inline">Overlay</span>
              <Monitor className="inline h-4 w-4 sm:hidden" />
            </Link>
          </motion.div>
          {user ? (
            <motion.div {...fadeIn(0.15)} className="flex items-center gap-2">
              <Link
                to="/admin"
                className="flex items-center gap-1.5 rounded-md bg-gold px-4 py-2 font-display text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_20px_-4px_oklch(0.82_0.17_85/0.6)] transition hover:bg-gold-glow"
              >
                <Settings className="h-3.5 w-3.5" />
                Admin
              </Link>
              <button
                onClick={() => signOut()}
                className="rounded-md border border-white/10 px-3 py-2 font-display text-xs font-semibold uppercase tracking-wider text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
              >
                Sign out
              </button>
            </motion.div>
          ) : (
            <motion.div {...fadeIn(0.15)}>
              <Link
                to="/auth"
                className="flex items-center gap-1.5 rounded-md bg-gold px-4 py-2 font-display text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_20px_-4px_oklch(0.82_0.17_85/0.6)] transition hover:bg-gold-glow"
              >
                <LogIn className="h-3.5 w-3.5" />
                Sign in
              </Link>
            </motion.div>
          )}
        </nav>
      </motion.header>

      {/* Hero — full-width single column */}
      <main className="relative z-10 mx-auto max-w-5xl px-6 pb-20 md:px-12">
        {/* Badge */}
        <motion.div {...fadeUp(0.1)} className="mb-4 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/5 px-3 py-1">
          <Radio className="h-3 w-3 animate-pulse text-gold" />
          <span className="font-display text-[10px] font-bold uppercase tracking-widest text-gold">
            Broadcast Ready
          </span>
        </motion.div>

        {/* Headline */}
        <div className="overflow-hidden">
          <motion.h1
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
            className="font-display text-5xl font-bold uppercase leading-[0.95] tracking-tight md:text-7xl"
          >
            Live <span className="text-gold">Free Fire</span><br />
            Tournament Overlay
          </motion.h1>
        </div>

        {/* Description */}
        <motion.p {...fadeUp(0.4)} className="mt-6 max-w-lg text-base text-muted-foreground">
          Broadcast-grade live leaderboard for Free Fire esports. Real-time eliminations,
          alive players, country flags. Drop it into OBS and it just works.
        </motion.p>

        {/* Buttons */}
        <motion.div {...fadeUp(0.5)} className="mt-8 flex flex-wrap gap-3">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }}>
            <Link
              to="/overlay"
              className="group flex items-center gap-2 rounded-md bg-gold px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_30px_-6px_oklch(0.82_0.17_85/0.7)] transition hover:bg-gold-glow"
            >
              <Monitor className="h-4 w-4" />
              Open Overlay
            </Link>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }}>
            <Link
              to="/admin"
              className="rounded-md border border-gold/40 px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-gold transition hover:bg-gold/10"
            >
              Manage Teams
            </Link>
          </motion.div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.65 }}
          className="mt-10 grid grid-cols-3 gap-3 border-t border-white/5 pt-6 text-xs"
        >
          {[
            { value: "Real-time", label: "Instant updates" },
            { value: "OBS", label: "Browser source" },
            { value: "Auto Sort", label: "By eliminations" },
          ].map((stat, i) => (
            <motion.div
              key={stat.value}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.7 + i * 0.1 }}
            >
              <div className="font-display text-lg font-bold text-gold">{stat.value}</div>
              <div className="text-muted-foreground">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* Live Preview card — below hero */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.5 }}
          className="relative mt-12"
        >
          <motion.div
            animate={{
              boxShadow: [
                "0 0 40px -10px oklch(0.82 0.17 85 / 0.15)",
                "0 0 70px -10px oklch(0.82 0.17 85 / 0.3)",
                "0 0 40px -10px oklch(0.82 0.17 85 / 0.15)",
              ],
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="absolute inset-0 -m-4 rounded-2xl bg-gradient-to-br from-gold/10 to-destructive/10 blur-2xl"
          />
          <div className="relative rounded-2xl border border-white/5 bg-black/40 p-6 backdrop-blur-xl">
            <div className="mb-3 flex items-center gap-1.5">
              <motion.span
                animate={{ opacity: [1, 0.4, 1] }}
                transition={{ duration: 1.4, repeat: Infinity }}
                className="h-2.5 w-2.5 rounded-full bg-destructive/70"
              />
              <span className="h-2.5 w-2.5 rounded-full bg-gold/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-alive/70" />
              <span className="ml-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                Live Preview
              </span>
            </div>
            <Leaderboard compact />
          </div>
        </motion.div>
      </main>
    </div>
  );
}
