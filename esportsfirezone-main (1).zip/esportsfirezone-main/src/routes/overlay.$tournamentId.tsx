import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flame, Skull, Crown, BarChart3, Radio, Swords } from "lucide-react";
import { useTeams } from "@/lib/useTeams";
import { useMatches } from "@/lib/useMatches";
import { useMatchScores, type TeamMatchScore } from "@/lib/useMatchScores";
import { useOverallStandings, type OverallStanding } from "@/lib/useOverallStandings";
import { Top3Hero } from "@/components/Top3Hero";
import { PLACEMENT_LABELS, RANK_COLORS } from "@/lib/ffws";

export const Route = createFileRoute("/overlay/$tournamentId")({
  component: PublicOverlay,
});

type OverlayTab = "live" | "overall" | string; // string = match id

function PublicOverlay() {
  const { tournamentId } = Route.useParams();
  const { teams } = useTeams(tournamentId);
  const { matches, liveMatch } = useMatches(tournamentId);
  const [activeTab, setActiveTab] = useState<OverlayTab>("live");

  useEffect(() => {
    document.documentElement.classList.add("overlay-transparent");
    document.body.classList.add("overlay-transparent");
    return () => {
      document.documentElement.classList.remove("overlay-transparent");
      document.body.classList.remove("overlay-transparent");
    };
  }, []);

  // Auto-switch to live match when it changes
  useEffect(() => {
    if (liveMatch && activeTab === "live") {
      // already on live, nothing to do
    }
  }, [liveMatch, activeTab]);

  const hasMatches = matches.length > 0;
  const resolvedMatchId: string | null =
    activeTab === "live" ? (liveMatch?.id ?? null) :
    activeTab === "overall" ? null :
    activeTab;

  const isOverall = activeTab === "overall";

  return (
    <div className="flex min-h-screen w-full flex-col p-3">
      {/* Tab bar */}
      {hasMatches && (
        <div className="mb-3 flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setActiveTab("live")}
            className={`flex shrink-0 items-center gap-1 rounded-md px-2.5 py-1.5 font-display text-[10px] font-bold uppercase tracking-wider transition backdrop-blur-md
              ${activeTab === "live" ? "bg-destructive/25 text-destructive ring-1 ring-destructive/40" : "bg-black/40 text-muted-foreground ring-1 ring-white/10 hover:bg-black/60 hover:text-foreground"}`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${liveMatch ? "bg-destructive animate-pulse" : "bg-muted-foreground"}`} />
            LIVE
          </button>

          {matches.map((m) => (
            <button
              key={m.id}
              onClick={() => setActiveTab(m.id)}
              className={`relative flex shrink-0 items-center gap-1 rounded-md px-2.5 py-1.5 font-display text-[10px] font-bold uppercase tracking-wider transition backdrop-blur-md
                ${activeTab === m.id ? "bg-gold/20 text-gold ring-1 ring-gold/40" : "bg-black/40 text-muted-foreground ring-1 ring-white/10 hover:bg-black/60 hover:text-foreground"}`}
            >
              {m.is_live && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive" />}
              {m.name}
            </button>
          ))}

          <button
            onClick={() => setActiveTab("overall")}
            className={`flex shrink-0 items-center gap-1 rounded-md px-2.5 py-1.5 font-display text-[10px] font-bold uppercase tracking-wider transition backdrop-blur-md
              ${isOverall ? "bg-gold/20 text-gold ring-1 ring-gold/40" : "bg-black/40 text-muted-foreground ring-1 ring-white/10 hover:bg-black/60 hover:text-foreground"}`}
          >
            <BarChart3 className="h-3 w-3" /> Overall
          </button>
        </div>
      )}

      {/* Content */}
      <AnimatePresence mode="wait">
        {isOverall ? (
          <motion.div key="overall" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
            <OverallView tournamentId={tournamentId} />
          </motion.div>
        ) : resolvedMatchId ? (
          <motion.div key={resolvedMatchId} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
            <MatchView matchId={resolvedMatchId} />
          </motion.div>
        ) : activeTab === "live" && !liveMatch ? (
          <motion.div key="no-live" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {hasMatches ? (
              <NoLiveScreen />
            ) : (
              <LegacyView tournamentId={tournamentId} />
            )}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

function NoLiveScreen() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16">
      <Radio className="h-8 w-8 text-muted-foreground opacity-40" />
      <p className="font-display text-xs uppercase tracking-widest text-muted-foreground opacity-60">
        No live match selected
      </p>
    </div>
  );
}

function MatchView({ matchId }: { matchId: string }) {
  const { sorted, loading } = useMatchScores(matchId);

  if (loading) return <LoadingSpinner />;

  const top3 = sorted.slice(0, 3);
  const rest = sorted.slice(3);
  const hasScores = sorted.some((s) => s.total_points > 0 || s.kills > 0 || s.placement > 0);

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <OverlayHeader label="Match Standings" />

      {!hasScores && sorted.length === 0 && (
        <div className="py-6 text-center font-display text-xs uppercase tracking-widest text-muted-foreground opacity-50">
          Waiting for scores…
        </div>
      )}

      {/* Top 3 hero */}
      {top3.length >= 2 && hasScores && (
        <div className="mb-2">
          <Top3Hero scores={top3} />
        </div>
      )}

      {/* Remaining teams */}
      <motion.div className="flex flex-col gap-1.5" variants={containerVariants} initial="hidden" animate="show">
        <AnimatePresence mode="popLayout">
          {(top3.length < 2 ? sorted : rest).map((s, i) => (
            <motion.div key={s.team_id} layout variants={itemVariants} initial="hidden" animate="show" exit={{ opacity: 0, scale: 0.9 }} transition={{ layout: { type: "spring", stiffness: 350, damping: 30 } }}>
              <MatchScoreRow score={s} rank={(top3.length >= 2 ? 3 : 0) + i + 1} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function OverallView({ tournamentId }: { tournamentId: string }) {
  const { standings, loading } = useOverallStandings(tournamentId);

  if (loading) return <LoadingSpinner />;

  const top3 = standings.slice(0, 3);
  const rest = standings.slice(3);
  const hasData = standings.length > 0;

  return (
    <div className="flex flex-col gap-3">
      <OverlayHeader label="Overall Standings" />

      {!hasData && (
        <div className="py-6 text-center font-display text-xs uppercase tracking-widest text-muted-foreground opacity-50">
          No scores yet
        </div>
      )}

      {top3.length >= 2 && (
        <div className="mb-2">
          <Top3Hero standings={top3} />
        </div>
      )}

      <motion.div className="flex flex-col gap-1.5" variants={containerVariants} initial="hidden" animate="show">
        <AnimatePresence mode="popLayout">
          {(top3.length < 2 ? standings : rest).map((s, i) => (
            <motion.div key={s.team_id} layout variants={itemVariants} initial="hidden" animate="show" exit={{ opacity: 0, scale: 0.9 }} transition={{ layout: { type: "spring", stiffness: 350, damping: 30 } }}>
              <OverallStandingRow standing={s} rank={(top3.length >= 2 ? 3 : 0) + i + 1} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function LegacyView({ tournamentId }: { tournamentId: string }) {
  const { teams, loading, flashId } = useTeams(tournamentId);

  return (
    <div className="flex flex-col gap-3">
      <OverlayHeader label="Live Standings" />
      <motion.div className="flex flex-col gap-1.5" variants={containerVariants} initial="hidden" animate="show">
        {loading && <div className="text-center text-xs text-muted-foreground py-4">Connecting…</div>}
        <AnimatePresence mode="popLayout">
          {teams.map((team, i) => (
            <motion.div key={team.id} layout variants={itemVariants} initial="hidden" animate="show" exit={{ opacity: 0, scale: 0.9 }} transition={{ layout: { type: "spring", stiffness: 350, damping: 30 } }}>
              <LegacyTeamRow team={team} rank={i + 1} flash={flashId === team.id} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function OverlayHeader({ label }: { label: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-gold/30 bg-gradient-to-r from-black/80 to-black/60 px-3 py-2 backdrop-blur-md">
      <div className="flex items-center gap-2">
        <Flame className="h-4 w-4 animate-pulse text-gold" strokeWidth={2.5} />
        <h2 className="font-display text-xs font-bold uppercase tracking-widest text-gold">{label}</h2>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive" />
        <span className="font-display text-[10px] font-bold uppercase tracking-wider text-foreground">LIVE</span>
      </div>
    </div>
  );
}

function MatchScoreRow({ score, rank }: { score: TeamMatchScore; rank: number }) {
  const colors = RANK_COLORS[rank as 1 | 2 | 3] ?? { text: "text-muted-foreground", border: "border-white/5", bg: "bg-transparent", glow: "" };
  const isTop3 = rank <= 3;

  return (
    <div className={`relative flex items-center gap-2.5 rounded-md border bg-black/55 px-3 py-2 backdrop-blur-md transition-all duration-500 ${isTop3 ? colors.border + " " + colors.glow : "border-white/5"}`}>
      {/* Rank */}
      <div className={`flex h-7 w-6 shrink-0 items-center justify-center font-display text-base font-bold ${isTop3 ? colors.text : "text-muted-foreground"}`}>
        {rank === 1 ? <Crown className="h-4 w-4 text-gold" strokeWidth={2} /> : rank.toString().padStart(2, "0")}
      </div>

      {/* Logo */}
      <div className="flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
        {score.team.logo_url ? (
          <img src={score.team.logo_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span className="font-display text-[9px] font-bold text-gold">{score.team.tag?.slice(0, 3).toUpperCase()}</span>
        )}
      </div>

      {/* Name + placement badge */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <img src={`https://flagcdn.com/w40/${(score.team.country_code || "us").toLowerCase()}.png`} alt="" className="h-3 w-4 rounded-sm object-cover ring-1 ring-white/10" />
          <span className="truncate font-display text-xs font-semibold uppercase tracking-wide text-foreground">{score.team.name}</span>
          {score.placement > 0 && (
            <span className="shrink-0 rounded bg-white/10 px-1 py-0.5 font-display text-[8px] font-bold uppercase text-muted-foreground">
              {PLACEMENT_LABELS[score.placement]}
            </span>
          )}
        </div>
        {/* Alive bars */}
        <div className="mt-1 flex gap-0.5">
          {Array.from({ length: score.team.max_players }).map((_, i) => {
            const alive = i < score.alive_players;
            return (
              <div key={i} className={`h-0.5 flex-1 rounded-full transition-all duration-500 ${alive ? "bg-alive shadow-[0_0_4px_oklch(0.78_0.18_142/0.7)]" : "bg-dead"}`} />
            );
          })}
        </div>
      </div>

      {/* Kill count */}
      <div className={`flex shrink-0 items-center gap-1 rounded px-1.5 py-0.5 ring-1 ${isTop3 ? colors.bg + " " + colors.border : "bg-gold/10 ring-gold/30"}`}>
        <Skull className={`h-3 w-3 ${isTop3 ? colors.text : "text-gold"}`} strokeWidth={2.5} />
        <span className={`font-display text-sm font-bold tabular-nums ${isTop3 ? colors.text : "text-gold"}`}>{score.kills}</span>
      </div>

      {/* Total points */}
      <div className="flex shrink-0 flex-col items-end">
        <span className={`font-display text-base font-black tabular-nums leading-none ${isTop3 ? colors.text : "text-foreground"}`}>{score.total_points}</span>
        <span className="font-display text-[8px] font-bold uppercase tracking-wider opacity-50">pts</span>
      </div>
    </div>
  );
}

function OverallStandingRow({ standing, rank }: { standing: OverallStanding; rank: number }) {
  const colors = RANK_COLORS[rank as 1 | 2 | 3] ?? { text: "text-muted-foreground", border: "border-white/5", bg: "bg-transparent", glow: "" };
  const isTop3 = rank <= 3;

  return (
    <div className={`flex items-center gap-2.5 rounded-md border bg-black/55 px-3 py-2 backdrop-blur-md transition-all duration-500 ${isTop3 ? colors.border + " " + colors.glow : "border-white/5"}`}>
      <div className={`flex h-7 w-6 shrink-0 items-center justify-center font-display text-base font-bold ${isTop3 ? colors.text : "text-muted-foreground"}`}>
        {rank === 1 ? <Crown className="h-4 w-4 text-gold" strokeWidth={2} /> : rank.toString().padStart(2, "0")}
      </div>

      <div className="flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
        {standing.team.logo_url ? (
          <img src={standing.team.logo_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span className="font-display text-[9px] font-bold text-gold">{standing.team.tag?.slice(0, 3).toUpperCase()}</span>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <img src={`https://flagcdn.com/w40/${(standing.team.country_code || "us").toLowerCase()}.png`} alt="" className="h-3 w-4 rounded-sm object-cover ring-1 ring-white/10" />
          <span className="truncate font-display text-xs font-semibold uppercase tracking-wide text-foreground">{standing.team.name}</span>
          <span className="shrink-0 rounded bg-white/10 px-1 py-0.5 font-display text-[8px] font-bold uppercase text-muted-foreground">
            {standing.matches_played}M
          </span>
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-1 rounded bg-gold/10 px-1.5 py-0.5 ring-1 ring-gold/30">
        <Skull className="h-3 w-3 text-gold" strokeWidth={2.5} />
        <span className="font-display text-sm font-bold tabular-nums text-gold">{standing.total_kills}</span>
      </div>

      <div className="flex shrink-0 flex-col items-end">
        <span className={`font-display text-base font-black tabular-nums leading-none ${isTop3 ? colors.text : "text-foreground"}`}>{standing.total_points}</span>
        <span className="font-display text-[8px] font-bold uppercase tracking-wider opacity-50">pts</span>
      </div>
    </div>
  );
}

import { Skull as SkullIcon } from "lucide-react";
import type { Team } from "@/lib/useTeams";

function LegacyTeamRow({ team, rank, flash }: { team: Team; rank: number; flash: boolean }) {
  const colors = RANK_COLORS[rank as 1 | 2 | 3] ?? { text: "text-muted-foreground", border: "border-white/5", bg: "bg-transparent", glow: "" };
  const isTop3 = rank <= 3;

  return (
    <div className={`group relative flex items-center gap-2.5 rounded-md border bg-black/55 px-3 py-2 backdrop-blur-md transition-all duration-500 ${isTop3 ? colors.border + " " + colors.glow : "border-white/5"} ${flash ? "animate-flash" : ""}`}>
      <div className={`flex h-7 w-6 shrink-0 items-center justify-center font-display text-base font-bold ${isTop3 ? colors.text : "text-muted-foreground"}`}>
        {rank === 1 ? <Crown className="h-4 w-4 text-gold" strokeWidth={2} /> : rank.toString().padStart(2, "0")}
      </div>
      <div className="flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded bg-secondary ring-1 ring-white/10">
        {team.logo_url ? (
          <img src={team.logo_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span className="font-display text-[9px] font-bold text-gold">{team.tag?.slice(0, 3).toUpperCase()}</span>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <img src={`https://flagcdn.com/w40/${(team.country_code || "us").toLowerCase()}.png`} alt="" className="h-3 w-4 rounded-sm object-cover ring-1 ring-white/10" />
          <span className="truncate font-display text-xs font-semibold uppercase tracking-wide text-foreground">{team.name}</span>
        </div>
        <div className="mt-1 flex gap-0.5">
          {Array.from({ length: team.max_players }).map((_, i) => {
            const alive = i < team.alive_players;
            return <div key={i} className={`h-0.5 flex-1 rounded-full transition-all duration-500 ${alive ? "bg-alive shadow-[0_0_4px_oklch(0.78_0.18_142/0.7)]" : "bg-dead"}`} />;
          })}
        </div>
      </div>
      <div className={`flex shrink-0 items-center gap-1 rounded px-1.5 py-0.5 ring-1 ${isTop3 ? colors.bg + " " + colors.border : "bg-gold/10 ring-gold/30"}`}>
        <SkullIcon className={`h-3 w-3 ${isTop3 ? colors.text : "text-gold"}`} strokeWidth={2.5} />
        <span className={`font-display text-sm font-bold tabular-nums ${isTop3 ? colors.text : "text-gold"}`}>{team.eliminations}</span>
      </div>
    </div>
  );
}

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-10">
      <div className="h-6 w-6 animate-spin rounded-full border-2 border-gold/30 border-t-gold" />
    </div>
  );
}

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16, scale: 0.97 },
  show: { opacity: 1, y: 0, scale: 1 },
};
