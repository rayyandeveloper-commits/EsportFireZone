import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/useAuth";
import { useTournaments } from "@/lib/useTournaments";

export const Route = createFileRoute("/overlay")({
  component: OverlayRedirect,
});

function OverlayRedirect() {
  const navigate = useNavigate();
  const { user, userId, loading } = useAuth();
  const { tournaments, loading: tLoading } = useTournaments(userId ?? null);

  useEffect(() => {
    if (loading || tLoading) return;
    if (!user || !userId) {
      navigate({ to: "/auth", replace: true });
      return;
    }
    if (tournaments.length > 0) {
      navigate({ to: "/overlay/$tournamentId", params: { tournamentId: tournaments[0].id }, replace: true });
    } else {
      navigate({ to: "/admin", replace: true });
    }
  }, [loading, tLoading, user, userId, tournaments, navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
      Loading overlay…
    </div>
  );
}
